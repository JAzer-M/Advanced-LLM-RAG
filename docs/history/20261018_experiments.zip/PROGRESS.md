# Advanced-LLM-RAG — Project Status & Codex Handoff

> **Document updated:** 2026-10-18  
> **Purpose:** Reliable handoff to Codex and future conversations  
> **Current development stage:** Stage 6 first-pass existing-case review complete; DeepSeek v4.1 Flash selected without new testing; next is a bounded Single-Agent prototype  
> **Source of truth rule:** This document summarizes the latest known project state, but Codex must inspect the actual repository/worktree before changing code. Uploaded snapshots and historical logs are not automatically identical to the current worktree.

---

## Latest verified state — 2026-10-18

This update supersedes conflicting pending items and engineering conclusions in the historical 2026-10-17 handoff below. Inspect current code before editing.

- **Current selection / explicit no-test instruction:** user switched from Kimi3 to `cn:deepseek-v4.1-flash`. Updated ignored local settings and public template, preserving the local Key; DeepSeek options are thinking disabled, temperature 0, max_tokens 4096. No generation, health probe, model listing or tests were run for this switch. All active generation calls still share the existing API client; retrieval/evidence/citation code is unchanged. The historical tested DeepSeek candidate was `cn:deepseek-v4-flash`, not this v4.1 route. Kimi's six-question/five-diagnostic results remain historical evidence, not v4.1 performance. Stage 6 has a first-pass review with strict semantic/abstention limits; Single-Agent, LangGraph, demo UI and final portfolio packaging remain to do. Summary: `evaluation/results/CURRENT_STATUS_AND_API.md`. Entries below record earlier states and do not override this selection.

- **Latest: user explicitly adopted Kimi3 and retired local generative inference.** Ignored API settings now request `cn:kimi-k3-1` with low reasoning effort and 4096 max completion tokens, without DeepSeek thinking-disabled or temperature=0. `llm.py` is an API-only compatibility entry point; main, decomposition and optional rewrite/HyDE generators share the configured proxy. No local fallback. Original Qwen implementation is preserved byte-for-byte as `evaluation/baselines/local_qwen_llm.py`; weights and prior artifacts were not deleted. CPU embedding/reranker remain local. All 34 relevant component checks passed. Six fresh full main runs completed, 12 successful API calls, no citation repair needed; five numeric/subject regression cases passed plus a fixed-old-prompt q4 answer passed assistant manual review. q1/q2/q3/q5 used exactly the old final prompts and Top-10; q4/q6 changed retrieval due decomposition, with q4 separately controlled on old evidence. Prior core omissions, scaling/masking and depth/overfitting errors disappeared in these runs; q6 refused and no longer drifted to 2025. q5 covers all core sizes/1x1 but still has overbroad wording and an AlexNet alias absent from context, so strict source-only review is not fully passed. Two HTTP503 requests were preserved; one minimal probe and targeted manual reruns completed the suite (21 requests total including 19 successful/2 failed). No generalized accuracy/uptime claim. Report: `evaluation/results/KIMI_MIGRATION_REPORT.md`; raw results/reviews: `evaluation/results/kimi_main_evaluation/`; PyCharm how-to: `docs/PYCHARM_API_GUIDE.md`; safe template: `api.example.json`. Next is the first bounded Single-Agent workflow, not more 2B-specific prompt tuning. Prior local-default/answer-only notes below are historical and superseded. Never print the local Key.

- **Latest: proxy model listing and first API comparison succeeded.** After the user configured the local Key, the proxy returned 20 model IDs. Added stdlib `src/api_llm.py`, answer-only backend selection in main (including its citation repair), and a two-question fixed-prompt comparison. Decomposition/retrieval remain on their existing local paths; `answer_backend` is still **local**. Prepared `cn:deepseek-v4-flash` as candidate plus disabled-thinking options in ignored local settings. Two real Chat Completions requests reused exact q3/q4 baseline prompts/evidence, no re-retrieval or repair; both returned non-truncated answers. Assistant manual review found core facts and citations supported, without prior scaling/masking/additive confusion or depth/overfitting causality. Two routing tests plus three citation-repair regressions passed. Only this candidate/two questions tested; no 20-model ranking, broad accuracy or price claim. q1/q5/q6 API checks and live API-main chain are pending. Report: `evaluation/results/API_MODEL_COMPARISON_REPORT.md`; raw answers/review: `evaluation/results/api_comparison/`. The prior pending-auth note below is superseded. Do not print local config Key or include it in artifacts.

- **Current steering: explore the user's local proxy before Stage 6C.** User supplied `http://127.0.0.1:7863/v1`, OpenAI Chat Completions protocol, and asked about available models. An unauthenticated model-list request reached the service and returned HTTP 401; no generation call or paper upload occurred. Prepared ignored `api.local.json` (empty key/model) and stdlib-only `list_api_models.py`; authenticated listing awaits local Key configuration. No model selected, no API adapter/main switch made, and no stronger-model performance claimed. If comparison proceeds, initially replace only final answering while keeping decomposition/retrieval fixed. See `evaluation/results/API_PROXY_SETUP.md`.

- **Latest: Stage 6B structural checking / bounded repair integrated.** Moved the citation checker into `src/citation_validation.py` (evaluation compatibility import retained) and added one-attempt source-ID mapping in main after initial generation. Validly cited drafts and recognized explicit insufficiency responses skip extra generation; invalid/incomplete mappings keep the original answer. A live full q1 run reproduced the baseline original answer/context; first numeric-key mapping failed and was preserved. Separating block IDs B1–B7 from numeric source IDs fixed the mapping on a repair-only rerun: seven blocks now carry existing citations and original wording is preserved. Four actual LLM calls total across the two versions; no runtime retry loop. Three targeted regression checks passed, including no-repair for real q2/q6, wording/newline preservation, and invalid-response fallback. Saved q2–q6 postprocessing replay made zero extra calls and kept answers unchanged. Manual review still finds partially supporting citations in q1 B1/B3, omitted qualifiers and missing core explanations; strict q1 answer acceptance remains false. q3/q4 semantic errors are not caught by syntax checking. Report: `evaluation/results/CITATION_REPAIR_REPORT.md`; artifacts: `evaluation/results/citation_repair/`. Next: Stage 6C targeted semantic grounding work, not a larger test framework or model replacement.

- **Latest: Stage 6A baseline completed.** Added a pre-run review protocol, evaluation-only citation structure/source lookup helper, and six-question answer collection runner. q1/q3/q4/q6 ran through live main (eight LLM calls including decomposition); q2/q5 reused hash-checked integration records. Six targeted citation-format checks passed and 15 representative manual-review excerpts/source references were checked against raw artifacts. q1 has no citations and misses core reasoning; q3 confuses scaling with decoder masking/additive attention; q4 answers core augmentation facts but invents a depth/overfitting causal link; q5 still omits qualifiers and has partial/wrong citations. q2 core answer is supported; q6 explicitly refused the stock-price question without inventing a price. q6 is one successful example, not validated general abstention. Decomposition also introduced an unintended 2025 date for q6; logged as a separate issue, not fixed. No production/model/data/Gold changes this round. Report: `evaluation/results/ANSWER_EVALUATION_BASELINE_REPORT.md`; raw answers/contexts and assistant manual review: `evaluation/results/answer_evaluation_baseline/`. Next: Stage 6B minimal citation-structure feedback/limited repair, followed by specific semantic failures; no broad evaluation framework or stronger model required.

- **Overall roadmap confirmed by user:** stages 1–4 have existing implementations/initial experiments; stage 5 context/evidence handling has initial main integration (not universal semantic correctness); stage 6 citation/answer evaluation includes q6-style abstention and is now in progress. Remaining afterward: Single-Agent workflow → LangGraph orchestration → one Streamlit/Gradio demo → final README, reproducibility notes and truthful resume description. Do not equate a module/substep closeout with completion of the entire project.

- **Latest: user-authorized main integration.** `main.py` now builds an evidence ledger after source-aware global reranking, retains all Top-10 raw passages, appends identity-anchor sources with consistent citation numbering, adds compact numeric/subject guidance, and prints program evidence/references before the model draft. No demo-specific selector or fixed retrieval snapshot is used in main. Seventeen existing component checks passed. Two live full main runs (q5/q2) completed with unchanged Top-10 IDs relative to historical B; 12/10 raw passages including anchors were retained, 25/24 ledger records validated, and q5's five layer specifications were correct. First q5 generation still misattributed GoogLeNet to VGG; after moving guidance after raw text, only q5 generation was rerun on the same fresh retrieval results. q2 prompt/context was unchanged. Final q5 no longer has the VGG 5×5 attribution error but omits the 1×1 variant, overstates all layers, and has unsupported/incomplete citations; strict answer acceptance still fails. q2 core explanation is supported; citation placement is imperfect. Five model calls total; no broad new test suite. Report: `evaluation/results/MAIN_EVIDENCE_INTEGRATION_REPORT.md`; artifacts: `evaluation/results/main_evidence_integration/`. Prior statements below that everything remains independent of main are historical and superseded by this authorization and implementation. Main can now accept fresh questions with evidence handling; no separate duplicate retrieval entry point is needed.

- Active entry point: `main.py`. `USE_HYDE=False`, `USE_MULTI_QUERY=False`, final context Top-10. Semantic chunks/index were checked at 378 records/vectors, 384 dimensions.
- The sub-query selector is now integrated. Its selected-key handling and global-score consistency have been checked. `src/reranker.py` now accepts `include_source=True` by default; `False` reproduces text-only scoring. Prompt newline escaping in `build_prompt()` has been corrected.
- `evaluation/run_context_selection_evaluation.py` was added and run successfully against q1–q5. Each question is decomposed/retrieved once and shared across A/B/C. Candidate IDs and sub-query inputs are frozen in `evaluation/results/context_selection_inputs.json`; full results/code/data fingerprints and selected IDs are in `context_selection_results.json`, with a readable `context_selection_results.md` beside it. HyDE is OFF; q6 is excluded from ranking metrics, not evaluated for abstention.

| Condition | Precision@10 | Recall@10 | MAP@10 | MRR@10 | q5 required claims |
|---|---:|---:|---:|---:|---:|
| A: text-only global ranking | 0.2800 | 0.8167 | 0.4283 | 0.6333 | 2/4 |
| B: source + text global ranking | 0.3200 | 0.8667 | 0.5784 | 0.7667 | 4/4 |
| C: source + text with sub-query selection | 0.3200 | 0.8667 | 0.5784 | 0.7667 | 4/4 |

- **Attribution:** B and C returned identical Top-10 IDs on all five questions. Current measured gains come from source-aware reranking, not an incremental benefit from the selector. Do not claim the selector improved coverage over B. Source-aware ranking regressed on q3 AP/RR, q4 AP, and q5 RR; inspect per-question results. These conclusions apply only to this five-question set.
- Current `main.py` was inspected after the user's edits: its final call now uses B (`rerank_results(..., include_source=True)`); the C selector remains defined for experiments.
- Answer generation has not passed full correctness/citation acceptance. q5 diagnostics exposed size/count confusion, cross-sentence layer binding errors, and attribution of a GoogLeNet discussion inside VGG.pdf to VGG. Controlled single-sentence extraction cases passed after explicit dimension rules and input minimization, but this is not a general extractor validation.
- `diagnose_entity_attribution.py` is a standalone prototype. Single-fragment guarding, manual previous-context, and automatic one-retry previous-context cases passed with local Qwen, plus 10 deterministic flow checks. It restricts expansion to the same document and same/previous page, records context chunk IDs, and keeps unsupported entities unknown. Name-in-quote checking is necessary but not a complete semantic support test. It is **not integrated into main.py**.
- **2026-10-18 frozen q5 answer diagnostic:** `diagnose_q5_evidence.py` extracts generic subject/claim/quote records per baseline chunk, checks structure/exact quotes, then generates from the ledger. No retrieval, neighbours, Gold injection, or production integration. First two six-field attempts yielded zero eligible records; all attempts/prompts were retained. The final three-field attempt produced eight eligible records and an answer in 11 calls / 71.32 seconds. DCNN second/later layer evidence is now expressed and the final count-as-size error disappeared, but VGG/GoogLeNet misattribution persists and VGG's 3×3 statement is overgeneralized. Quote/number checks are not semantic verification; answer acceptance **failed**. Six flow/guard checks passed. See `evaluation/results/q5_evidence_review.md` and `q5_evidence_diagnostic_v3.json`.
- **Numeric-rule-only follow-up:** added symbolic H×W×C/count/channel definitions only to extraction prompts. All ten prompts matched v3 exactly after removal of that one block; 15 integrity checks and six existing flow tests passed. The actual run produced nine structurally eligible records in 11 calls / 60.76 seconds. Spatial sizes were clearer in the answer, but channel-width confusion and VGG attribution persisted; third/fifth DCNN layers were omitted, record IDs were used as citations, and the answer contradicted itself about first-layer evidence. Answer acceptance **failed**. See `evaluation/results/q5_numeric_rules_review.md`, `q5_numeric_rules_comparison.json`, and `q5_evidence_numeric_rules.json`. Main/model settings/Gold unchanged; no production integration.
- **Numeric parser and compact evidence follow-up:** implemented `src/numeric_evidence.py` and the standalone `diagnose_q5_numeric_pipeline.py`. Five real convolution-layer specifications are parsed correctly, with exact raw quote offsets; unknown layers/channels are preserved and image/channel-width counterexamples are rejected. All 21 targeted tests passed. Two JSON-presentation arms failed and were retained in `q5_numeric_pipeline.json`. A subsequent compact-text arm using parsed facts, conservative author filtering and architecture-passage prioritization improved the answer: correct size comparison, no VGG 5×5 misattribution, and valid citations. It used one model call / 28.87 seconds; original summary still omits some layer bindings and the VGG 1×1 variant. Program evidence table is complete; strict full-answer acceptance is **not** claimed. Stopped tuning at this improvement as requested. See `evaluation/results/NUMERIC_EVIDENCE_REPORT.md`, `q5_numeric_pipeline_compact.json`, and `numeric_pipeline_acceptance.json`. Main remains unchanged.
- **Four-issue grounding follow-up (independent of main):** added `src/grounded_evidence.py` with bounded identity context, typed/extractive support validation and complete evidence rendering; expanded numeric formats and explicit Markdown tables. 27 development/regression checks passed. Predeclared local challenge: exact numeric recall 10/45 → 42/45, precision 90.91% → 97.67%; unsupported Chinese/by/cross-sentence cases retained as failures. Six negative cases had no false extraction. All 16 authored subject cases passed, BUT real chunk 250 still yields an incorrect ICLR subject candidate, so entity generalization is **not solved**. Across q1–q5, 126 canonical records and 524 tampering checks passed; this is a typed/extractive contract, not arbitrary NLI (five true freeform paraphrases were deliberately rejected by the contract). Actual Qwen selection on q5/q2 restored 17/21 omitted records; 100% coverage applies only to accepted ledger entries. Core hashes were frozen before locked evaluation and not tuned afterward; main/model/Gold/baseline unchanged. Report: `evaluation/results/GROUNDING_GENERALIZATION_REPORT.md`.
- **Targeted subject fix after the locked evaluation:** a small change in `src/grounded_evidence.py` recognizes appositive subject/predicate clauses and stops promoting bare name candidates from previous context. Both chunk-250 records now resolve to GoogLeNet using chunk 249; q5's five numerical records and all 25 evidence records are preserved. One real regression was added; seven component checks and one q5 run passed, with zero model calls. Historical locked results remain unchanged. See `evaluation/results/SUBJECT_ATTRIBUTION_FIX.md` and `subject_attribution_fix.json`. No main integration.
- **Working preference:** prioritize small changes for observed problems and targeted verification; avoid unnecessary test expansion or speculative defensive code. Next work should assess practical evidence output and remaining concrete failures, rather than automatically adding broad evaluation frameworks. General entity resolution and unrestricted semantic entailment are still not claimed; no production integration requested or performed.
- **Readable demo / prototype closeout:** added `demo_grounded_qa.py`, replaying existing q5/q2 contexts into a model draft, program key facts, references and full evidence attachments. q5 shows all five layer records plus VGG 1×1/3×3 evidence; q2 explains the positional-encoding motivation. Fixed the observed `we also utilise` gap and prevented duplicate supplemental records from the same chunk. Three model calls total (q5 initial + q2 + corrected q5); no new evaluation suite. Raw drafts are retained: q5 still omits direct [3] support for its 5×5 summary statement and lacks explicit layer mapping in prose, while the program table is complete/correct; q2 includes some secondary details. Therefore the **independent evidence prototype/demo stage can close**, not full semantic-answer or production acceptance. Main/model/Gold unchanged. See `evaluation/results/STAGE_CLOSEOUT_REPORT.md` and `evaluation/results/grounded_demo/q5.md`, `q2.md`. This entry point replays frozen retrieval results, not arbitrary fresh retrieval.
- These changes/results have not been committed or pushed during this session.
- **User decision: keep the existing 2B model.** Optimize within current local resources; do not make a stronger-model comparison the required next step. A single q5 trial requesting one bullet per evidence item failed (512 generated tokens, repetition, no citations); its prompt change was reverted and raw results retained in `grounded_demo_structured/q5.json`. The independent demo now displays program facts/exact quotations before the auxiliary model draft. q5/q2 Markdown was re-rendered from saved answers with zero additional calls; numeric records, raw baseline JSON, main/model/Gold remain unchanged. This improves evidence visibility, not generation accuracy or generalization. See `evaluation/results/LOCAL_MODEL_DECISION.md`. A practical future direction is an independent entry point for fresh questions/retrieval; it has not been implemented or integrated into main.

---

## 0. Start Here — Read This First

This is a research-paper analysis RAG project intended for learning, reproducible experimentation, and AI/LLM internship portfolio use. The goal is not merely to make a PDF chatbot work. The system should retrieve evidence across research papers, construct a bounded context, generate evidence-grounded answers with citations, and later evolve into a Single-Agent / Agentic RAG workflow.

### Current engineering conclusion

The immediate bottleneck is **final context selection for decomposed comparison questions**, not a lack of retrieval candidates and not HyDE.

For q5, the VGG/DCNN convolution-filter comparison:

- The latest recorded candidate pool contains evidence for **4/4 required claims** and **3/3 supplementary claims**.
- After the original comparison question is used to globally rerank the merged candidates, the final Top-10 contains only **2/4 required claims** and **0/3 supplementary claims**.
- Therefore, the next experiment should test whether a context-selection strategy can preserve complementary evidence from each sub-query while retaining a strict Top-10 context budget.

### Critical distinction between known state and pending work

| Item | Latest known status | Do not assume |
|---|---|---|
| `main_cleaned.py` | User previously confirmed that the cleaned file ran without a problem | Do not assume it is the current production `main.py` |
| `main(9).py` snapshot | Contains `USE_HYDE = True` | Do not assume the production setting has already been changed |
| HyDE experiment | Production-aligned ON/OFF comparison completed; no overall benefit observed | Do not restart HyDE tuning without a new, explicit hypothesis |
| Context Selection | Design identified; a draft function was added in an uploaded `main(20261017-082058).py` snapshot | Do not claim the function is fixed, integrated, or validated |
| Draft function | The latest review identified a list/dictionary misuse and possible score inconsistency | Inspect the actual worktree before deciding what remains to fix |
| Current Git state | Not established by this document | Run `git status` before editing or committing |

### First actions for Codex

Before modifying code:

1. Inspect the actual repository root and `git status`.
2. Identify the actual active `main.py`, current `PROGRESS.md`, evaluation scripts, question set, and q5 claim mapping.
3. Compare the worktree with the uploaded snapshots if those snapshots are available; do not assume their contents are identical.
4. Inspect the current context-selection draft and its call sites.
5. Make only the smallest code change needed for the next test. Do not rewrite the whole pipeline, package a replacement project, or bulk-generate files.

The immediate goal is to **understand and finish the current feature**, not to redesign the whole RAG system.

---

## 1. Project Goals and Scope

### End goal

Build a reproducible RAG system for analysis of research papers:

```text
Research Paper PDFs
    ↓
PDF Parsing + Metadata
    ↓
Fixed / Recursive / Semantic Chunking
    ↓
Embedding + FAISS / BM25
    ↓
Dense + BM25 + RRF
    ↓
Cross-Encoder Reranking
    ↓
Query Optimization
(Rewrite / Query Decomposition / HyDE experiments)
    ↓
Context Management + Evidence Selection
    ↓
Citation Validation + Answer-level Evaluation
    ↓
Local Qwen Answer Generation
    ↓
Single-Agent → LangGraph → Streamlit / Gradio
    ↓
Reproducible Demo + README + Résumé Presentation
```

### Explicitly out of scope for this project

- Fine-tuning, including LoRA / QLoRA.
- Transformer architecture research.

These belong to the user's separate Transformer project. Do not reintroduce them into this RAG roadmap.

---

## 2. User Environment and Working Preferences

### Devices and tools

- **MacBook Air + PyCharm:** Main development environment for code, PDF parsing, retrieval modules, evaluation, and Git.
- **Windows laptop with NVIDIA RTX 5060:** Local LLM inference and heavier model workloads.
- **Local generation model:** `Qwen/Qwen3.5-2B`, previously confirmed to run on Windows.
- **Embedding model:** `sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2`, 384-dimensional embeddings with normalized vectors.
- **Reranker:** `BAAI/bge-reranker-base` in the latest recorded evaluation setup; CPU was used for that evaluation.
- **Version control:** Git/GitHub. A Git push does not transfer ignored virtual environments, model weights, or Hugging Face caches.

### Required collaboration style

These are project requirements, not optional style suggestions.

1. **The user prefers to handwrite code in Chat/PyCharm.** Do not produce complete replacement files, bulk implementations, downloadable bundles, or project-wide edits unless the user explicitly asks for them or agrees after discussing why they are needed.
2. Before introducing each feature, explain:
   - the problem and evidence that motivate it;
   - the feature's purpose and expected effect;
   - the design options and the reason for the selected approach;
   - trade-offs, risks, and how success will be measured.
3. Give one clear, actionable coding step at a time. Provide the exact insertion/replacement location and only the necessary code for that step.
4. Explain non-obvious code, data structures, parameters, control flow, and design choices. Do not merely paste code with a superficial summary.
5. Do not explain trivial code at excessive length when the user explicitly asks to focus on implementation; follow the user's latest instruction.
6. Do not repeat experiments whose results already answer the question unless code/data changed or a new hypothesis requires them.
7. Be decisive when existing evidence is sufficient. Do not use “one more check” as a default reason to delay progress.
8. Do not claim code was run, tested, committed, pushed, or integrated unless that action actually happened.
9. Clearly separate facts, inference, decisions, proposed work, and unverified state.
10. Do not silently broaden the task. If a design decision materially changes the architecture or the user's workflow, explain it and ask before proceeding.

---

## 3. Corpus and Data Pipeline

### Current corpus

`data/raw/` contains three PDFs, 32 pages total:

| File | Pages | Topic |
|---|---:|---|
| `Attention is all you need.pdf` | 11 | Transformer |
| `DCNN.pdf` | 7 | AlexNet / Deep CNN |
| `VGG.pdf` | 14 | VGG |
| **Total** | **32** | |

There is **no `ResNet.pdf`** in the current corpus. Do not create evaluation questions or describe results as if ResNet were indexed.

### PDF parsing

Core module: `src/pdf_loader.py`

Known implemented functionality:

- PyMuPDF PDF text extraction.
- Metadata fields such as `source`, `page`, `title`, `section`, and `text`.
- Detection of some numbered/bold headings and section inheritance.
- Cleanup of some headers, page labels, and blank lines.
- Text-order handling for the two-column DCNN paper has been addressed in prior work.

Typical chunk shape:

```python
{
    "chunk_id": 0,
    "text": "...",
    "source": "VGG.pdf",
    "page": 2,
    "title": "...",
    "section": "2.3 DISCUSSION",
}
```

Having `title` and `section` metadata does **not** prove every retriever includes these fields in its indexed text. Do not describe the pipeline as fully metadata-aware unless the current code confirms it.

### Chunking variants

- **Fixed / Basic:** `chunk_size=500`, `chunk_overlap=100`; these are character counts, not token counts.
- **Recursive:** Attempts natural boundaries such as paragraphs, line breaks, and spaces before falling back to smaller splits.
- **Semantic:** Sentence splitting → sentence embeddings → adjacent-sentence similarity → semantic boundaries → maximum-length handling → character-splitting fallback when needed.

Latest recorded Semantic settings: `max_chunk_size=500`, `percentile=10`. Sentence splitting has been adjusted for abbreviations such as `e.g.`, `i.e.`, `etc.`, and `vs.`.

### Current recorded Semantic data version

- Latest recorded `chunks_semantic(6).json`: **378 chunks**.
- Latest recorded validation: FAISS vectors = 378 and chunks = 378.
- Expected project paths: `data/processed/chunks_semantic.json` and `data/processed/faiss_semantic.index`.

This is a historical recorded validation, not a fresh inspection of the user's current machine. Codex should check the actual files and index before relying on the count.

Semantic chunking has historically processed documents/pages independently and does not guarantee cross-page chunks. Cross-page chunking can be revisited later, but it is not the immediate next task: the latest q5 evidence indicates a more direct final-context-selection bottleneck. Do not rebuild indexes now without new evidence.

---

## 4. Retrieval Pipeline and Key Modules

Known core modules:

```text
src/pdf_loader.py
src/chunking.py
src/chunking_recursive.py
src/chunking_semantic.py
src/embedding.py
src/vector_store.py
src/chunk_storage.py
src/retriever.py
src/bm25_retriever.py
src/hybrid_retriever.py
src/reranker.py
src/query_rewriter.py
src/query_decomposer.py
src/hyde.py
```

Core pipeline:

```text
Original Query
    ├── Dense Retrieval (MiniLM + FAISS)
    └── BM25 Retrieval
             ↓
          RRF Fusion
             ↓
         Candidate Pool
             ↓
     Cross-Encoder Reranking
             ↓
       Context Construction
             ↓
      Qwen Answer Generation
```

Important implementation facts:

- FAISS uses `IndexFlatIP`; with normalized embeddings, inner product can rank by cosine similarity.
- BM25 provides lexical retrieval.
- RRF fuses ranked lists. `RRF_K=60` is the rank-smoothing constant; it does not mean “return 60 results.”
- A Cross-Encoder reranks only the candidates it receives. It cannot recover a gold chunk absent from the candidate pool.
- Current context construction has historically used `(source, page, text)` as a deduplication key. Inspect the current code before relying on this in a new implementation.

### Latest recorded main snapshot parameters

The uploaded `main(9).py` snapshot had:

```python
USE_MULTI_QUERY = False
USE_HYDE = True
RETRIEVAL_TOP_K = 60
RRF_TOP_K = 60
RERANK_TOP_K = 10
RRF_K = 60
```

The same snapshot used the Semantic index/chunks and checked that `index.ntotal == len(chunks)`.

**Important:** The HyDE experiment decision is to turn HyDE off by default, but the uploaded snapshot still had `USE_HYDE = True`. The current worktree must be inspected to establish whether this setting has since changed. Do not mark this item complete based only on the decision.

### Recorded main-pipeline flow

1. Load the embedding model, FAISS index, and chunk records.
2. Read the original user query.
3. Call `decompose_query(query)`; its result determines whether sub-query retrieval is used.
4. Retrieve Dense Top-60 and BM25 Top-60 for the original query.
5. If `USE_MULTI_QUERY=True`, rewrite to a single additional query and run Dense + BM25. This branch is not a true multi-query generation pipeline.
6. If decomposition is needed, run Dense + BM25 + RRF for each sub-query.
7. If HyDE is enabled, generate a hypothetical document, run Dense retrieval on it, and add those results into the original-query RRF fusion.
8. Merge original-query and sub-query retrieval results.
9. Deduplicate candidates.
10. Historically, rerank the merged candidate pool against the **original query only**, then select Top-10.
11. Build context and call `generate_answer()`.

Step 10 is the current Context Management entry point.

---

## 5. Query Optimization Status

### Query Rewrite

Module: `src/query_rewriter.py`

Purpose: Rephrase a question to make it more retrieval-friendly.

A first-pass implementation and experiments exist. A prior qualitative test showed the original query and rewritten query returning the same Top-10 and answer, so there was no clear demonstrated gain in that test. The current main snapshot used `USE_MULTI_QUERY` to control this branch, defaulting to `False`.

### Naming caveat: `USE_MULTI_QUERY`

The recorded branch generates **one rewritten query**, then performs additional Dense + BM25 retrieval. Strictly speaking, this is Query Rewrite + additional retrieval, not a complete Multi-Query pipeline that generates and searches several distinct queries.

Do not interrupt the current mainline just to rename this flag. Document the implementation accurately in reports and résumé descriptions.

### Query Decomposition

Module: `src/query_decomposer.py`

Purpose: Break complex questions into sub-questions that can retrieve complementary evidence. For q5, this supports retrieving evidence for VGG and DCNN separately before comparing them.

The main pipeline calls `decompose_query(query)` and uses `needs_decomposition` to decide whether to retrieve for sub-queries. First-pass implementation and experiments are complete. Keep this capability because cross-paper comparison needs evidence from both sides.

### HyDE

Module: `src/hyde.py`

Function recorded in the implementation:

```python
generate_hypothetical_document(query: str) -> str
```

Flow: original query → LLM-generated hypothetical document → Dense retrieval using that document → real corpus chunks.

The hypothetical document is only a retrieval aid. It is **not** real source evidence and must never be cited as if it came from a paper.

**Decision: stop prioritizing HyDE tuning for the current corpus and evaluation.** Keep the implementation and experiment records, but do not repeatedly alter the hypothetical-document prompt or generation length without a new, testable hypothesis.

---

## 6. Production-Aligned HyDE ON/OFF Results

The latest recorded comparison held the original-query Dense/BM25 results, rewrite setting, decomposition decisions and sub-query retrieval, RRF, reranker, evaluation questions, and runtime Gold Evidence mapping constant. The ON condition additionally included HyDE Dense retrieval results.

### Overall metrics

| Metric | K | HyDE OFF | HyDE ON | ON − OFF |
|---|---:|---:|---:|---:|
| Mean Precision | 5 | 0.3600 | 0.3600 | 0.0000 |
| Mean Recall | 5 | 0.4750 | 0.4750 | 0.0000 |
| MAP | 5 | 0.3367 | 0.3367 | 0.0000 |
| MRR | 5 | 0.6000 | 0.6000 | 0.0000 |
| Mean Precision | 10 | 0.2800 | 0.2800 | 0.0000 |
| Mean Recall | 10 | 0.8167 | 0.8167 | 0.0000 |
| MAP | 10 | 0.4283 | 0.4236 | -0.0048 |
| MRR | 10 | 0.6333 | 0.6286 | -0.0048 |
| Mean Precision | 20 | 0.1500 | 0.1500 | 0.0000 |
| Mean Recall | 20 | 0.8500 | 0.8500 | 0.0000 |
| MAP | 20 | 0.4450 | 0.4402 | -0.0048 |
| MRR | 20 | 0.6333 | 0.6286 | -0.0048 |

### Candidate-pool coverage

| Metric | HyDE OFF | HyDE ON |
|---|---:|---:|
| Mean per-question Gold coverage | 0.9750 | 0.9750 |
| Micro Gold coverage | 20/21 = 0.9524 | 20/21 = 0.9524 |

### Interpretation and decision

- Top-5 metrics were identical.
- Top-10 and Top-20 Precision/Recall were identical; MAP and MRR were slightly lower with HyDE ON.
- Candidate-pool Gold coverage was identical.
- These results do not support a retrieval benefit from HyDE in the current implementation and five-question evaluation.

This is a project-specific engineering decision, not a claim that HyDE is ineffective in every dataset or task.

**Pending configuration cleanup:** Set the actual worktree's production default to `USE_HYDE = False` if it has not already been changed. Keep `src/hyde.py` and the experiment script/history.

---

## 7. Current Bottleneck: Context Management for q5

### q5 question

> How do VGG and DCNN differ in their use of convolutional filter sizes?

The four required semantic claims are:

1. VGG primarily uses small 3×3 convolutional filters.
2. DCNN's first convolutional layer uses 11×11 filters.
3. DCNN's second convolutional layer uses 5×5 filters.
4. DCNN's later convolutional layers use 3×3 filters.

Three recorded supplementary claims:

- Stacking small VGG filters can reduce parameter count relative to a single larger filter with comparable receptive field.
- Stacking small filters introduces additional nonlinearities.
- Some VGG configurations include 1×1 convolutional layers.

### Latest recorded q5 claim coverage

| Stage | HyDE OFF | HyDE ON |
|---|---:|---:|
| Candidate pool — required claims | 4/4 | 4/4 |
| Candidate pool — supplementary claims | 3/3 | 3/3 |
| Reranked Top-5 — required claims | 1/4 | 1/4 |
| Reranked Top-10 — required claims | 2/4 | 2/4 |
| Reranked Top-20 — required claims | 2/4 | 2/4 |
| Reranked Top-10 — supplementary claims | 0/3 | 0/3 |

### Recorded Gold-chunk ranking diagnostic

These IDs are tied to the specific chunk/claim-mapping version in the experiment. Do not assume they remain valid after re-chunking or replacing files.

| Chunk ID | Claim | HyDE OFF rank | HyDE ON rank |
|---:|---|---:|---:|
| 157 | DCNN first layer: 11×11 | 10 | 10 |
| 158 | DCNN second layer: 5×5 | 2 | 2 |
| 159 | DCNN later layers: 3×3 | 22 | 22 |
| 224 | VGG small 3×3 receptive field | 24 | 24 |
| 241 | Alternative acceptable evidence for VGG small filters | Not in candidate pool | Not in candidate pool |
| 245 | VGG small-filter stack adds nonlinearities | 69 | 66 |
| 246 | VGG small-filter stack reduces parameters | 27 | 27 |
| 280 | Some VGG configurations use 1×1 filters | 54 | 54 |

### Correct interpretation

- The original Gold Chunk set has 7/8 chunks covered because Chunk 241 is absent from the candidate pool.
- The claim mapping also accepts Chunk 224 as evidence for the VGG small-filter claim, so the VGG required claim is still covered at candidate-pool stage.
- The candidate pool contains evidence for all four required claims and all three supplementary claims.
- The original-query global reranker places Chunk 158 at rank 2 and Chunk 157 at rank 10, but Chunk 159 and Chunk 224 at ranks 22 and 24. Most supplementary evidence is also outside Top-10.
- Therefore, the most actionable current bottleneck is **how the final Top-10 is selected**, not whether HyDE can retrieve Chunk 241.

---

## 8. Context Selection — Design Goal and Current Draft State

### Why this feature is needed

A cross-paper comparison question can require evidence from multiple sub-questions. A single global relevance score for the original comparison question may favor one paper or one aspect of the question, even when the candidate pool already contains evidence for every required claim.

The proposed strategy is to:

1. Preserve the existing retrieval and RRF candidate pool.
2. Rerank each sub-query's own candidate list using that sub-query as the Cross-Encoder query.
3. Reserve a small number of high-ranked candidates from each sub-query, using a balanced/round-robin selection approach.
4. Deduplicate selected chunks.
5. Fill remaining context slots from the original-query global ranking.
6. Keep final context capped at Top-10.
7. Log why each chunk was selected, its sub-query rank(s), its original-query global rank, and its final inclusion.
8. Evaluate q5 claim coverage, then run the same method across q1–q5.

The first implementation idea uses `reserve_per_subquery=3`, but this is an initial hyperparameter, **not an established optimum**. If the number of sub-queries is large, reservation must never exceed the final Top-K budget. Duplicate chunks must not consume multiple slots.

### Current draft in uploaded snapshot

The user manually added a draft function to an uploaded snapshot named `main(20261017-082058).py`. The recorded function name was:

```python
select_context_with_subquery_converge(...)
```

The intended name was `select_context_with_subquery_coverage(...)`.

The latest code review identified these issues in that uploaded snapshot:

1. `selected = []` was used as if it were a dictionary (`selected[key] = candidate`, `.values()`), which will fail at runtime.
2. Sub-query reranking mutates/adds score fields. If the final list is selected using sub-query-ranked dictionaries but ordered by the original-query global ranking, the stored `rerank_score` can disagree with the score that determined the final order.
3. The main pipeline still used its existing global-reranking call; the draft selector was not yet integrated.
4. The Prompt builder in that snapshot appeared to use `\\n` where actual newlines were intended. Inspect the active file to confirm.
5. The function had not been confirmed as fixed, integrated, or evaluated after the review.

These observations apply to the uploaded snapshot, not necessarily the current worktree. **Codex must inspect the actual current file and `git diff` before deciding which fixes are still needed.** Do not assume the user applied the proposed fixes.

### Important implementation principles

- Use a stable chunk identity for selection/deduplication, consistent with the current data model. The recorded pipeline uses `(source, page, text)`; inspect the current code and confirm that this identity is suitable.
- Separate **selection membership** from **candidate result objects**. For example, keep selected chunk keys, then retrieve the corresponding objects from the original-query `global_ranked` list. This avoids accidentally retaining a sub-query score in a result whose final order is defined by the global ranking.
- Keep the final list at or below `top_k`.
- Preserve all source metadata needed for citation: at least `source`, `page`, and `text`, plus `title`, `section`, and stable identifiers if present.
- Handle no-decomposition questions by preserving existing global-reranking behavior.
- Handle empty sub-query result lists and duplicate evidence safely.
- Do not treat sub-query rerank scores as directly comparable across different queries unless the reranker and scoring behavior justify it.
- Instrument the selector. The experiment must explain why a chunk was included, not only print a final Top-10.

### Suggested acceptance criteria

First run a focused test of the selector without loading the full LLM:

- It returns at most `top_k` unique chunks.
- It handles no sub-queries by returning the original-query global Top-K.
- It reserves candidates across multiple sub-queries without allowing one sub-query to consume the entire context when others have usable evidence.
- It handles overlapping candidates and empty sub-query result lists.
- Final result objects and displayed scores correspond to the chosen ordering policy.
- Source/page/text metadata remains intact.

Then run the production-aligned q5 test:

- Candidate pool stays fixed between baseline and new selector.
- Required Claim Coverage@10 is reported for both.
- The initial target is 4/4 required claims, but the result must be measured, not assumed.
- Record the selected chunks, their sub-query ranks, global ranks, and why any claim remains uncovered.

If q5 improves, run q1–q5 with the same evaluation set and mapping. Retain the new strategy only if the gains are meaningful and do not cause an unacceptable regression on the other questions.

Do not simultaneously alter chunking, Gold Evidence, HyDE prompts, reranker model, and context selection. That would make the experiment uninterpretable.

---

## 9. Evaluation Set and Gold Evidence

The latest recorded `evaluation/questions.json` contained q1–q6:

| ID | Topic | Type |
|---|---|---|
| q1 | Why VGG uses small 3×3 convolution filters | Single-paper |
| q2 | Why the Transformer uses positional encoding | Single-paper |
| q3 | The role of scaled dot-product attention in the Transformer | Single-paper |
| q4 | How DCNN uses data augmentation to reduce overfitting | Single-paper |
| q5 | Compare VGG and DCNN convolution-filter sizes | Cross-paper comparison |
| q6 | An NVIDIA historical stock-price question unavailable in the corpus | Out-of-scope / no-answer |

q6 has no Gold Evidence and is skipped by retrieval-ranking metrics. This does **not** mean abstention behavior has been evaluated. No-answer behavior requires a separate answer-level evaluation.

### Gold Evidence rules

- The question set records evidence using source, page, and quote.
- The evaluation script matches these quotes against the current `chunks_semantic.json` to derive runtime Gold Chunk IDs.
- Numeric chunk IDs from old logs must not be reused blindly across chunk versions.
- `claim_gold_q5.json` uses acceptable chunk IDs to represent multiple valid evidence chunks for a claim. These IDs must match the chunk version used in that evaluation.
- Do not change Gold Evidence merely to improve scores. Change it only when the original paper and annotation genuinely disagree, and document the reason.

The latest recorded HyDE comparison matched Gold Evidence for q1–q5 and skipped q6 because it had no Gold Evidence.

---

## 10. Metrics and Experiment Hygiene

### Main metrics

- **Precision@K:** fraction of the Top-K results that are relevant.
- **Recall@K:** fraction of all gold evidence retrieved in the Top-K.
- **AP@K / MAP@K:** ranking-sensitive average precision; MAP is the mean AP across valid questions.
- **RR@K / MRR@K:** reciprocal rank of the first relevant result and its mean across questions.
- **Candidate-pool Gold Coverage:** whether the pre-rerank candidate pool contains the gold evidence.
- **Claim Coverage:** whether the selected evidence supports the semantic claims needed to answer a question.

Gold Chunk Coverage and Claim Coverage are not identical. A claim can have more than one acceptable supporting chunk. For q5, missing Chunk 241 does not mean the VGG small-filter claim is uncovered if accepted Chunk 224 is present.

### Historical-result discipline

Detailed historical per-question metrics and older experimental variants belong in `EVALUATION_LOG.md`, if that file exists in the actual worktree.

Historical runs include:

- 330-chunk Basic/Fixed baseline.
- Earlier Recursive/Semantic comparisons.
- Dense, BM25, Hybrid, and reranker experiments under different question-set versions.
- Standalone HyDE retrieval, Dense + HyDE Dense RRF, and Union + Cross-Encoder experiments.
- Earlier `USE_MULTI_QUERY` comparisons.

Do not combine these into a single leaderboard with the latest production-aligned HyDE ON/OFF results. For each comparison, record at least:

- evaluation questions and version;
- Gold Evidence/claim mapping version;
- chunk and index version;
- query branches enabled;
- candidate-pool size;
- RRF settings;
- reranker model;
- final K;
- context-selection policy;
- whether the numbers are measured results or a design target.

### Work not to repeat without a new reason

Do not repeat identical HyDE ON/OFF runs, initial Rewrite/Decomposition experiments, or index rebuilding merely to feel more certain. Re-run only if code, data, configuration, or a testable hypothesis changes.

---

## 11. Next Roadmap and Completion Conditions

### Current stage — Context Management

- [ ] Inspect the actual worktree and establish the active `main.py` and Git status.
- [ ] Ensure the production default is `USE_HYDE = False` if it is still enabled; preserve HyDE code/history.
- [ ] Inspect and fix the draft Context Selection function only where needed.
- [ ] Test selector edge cases and score/object consistency.
- [ ] Integrate the selector at the current final-reranking/context-selection point.
- [ ] Compare q5 baseline vs new selector using the same candidate pool.
- [ ] Run q1–q5 once if q5 shows a meaningful gain.
- [ ] Record actual measured results in `EVALUATION_LOG.md` and update this handoff document.
- [ ] Commit changes only when the user requests or approves the Git action.

### Next stage — Citation Validation and Answer-level Evaluation

- [ ] Check whether each generated claim is supported by the cited chunk.
- [ ] Check citation numbering and mapping to the actual context.
- [ ] Check source/page correctness.
- [ ] Evaluate answer correctness, evidence faithfulness, and unsupported claims.
- [ ] Evaluate refusal/abstention on q6 and other out-of-scope questions.

### Later — Agentic RAG and demo

- [ ] Implement a Single-Agent decision workflow for retrieval, decomposition, evidence gathering, and abstention.
- [ ] Introduce LangGraph after the single-agent behavior is understandable and measurable.
- [ ] Build a Streamlit or Gradio demo.
- [ ] Complete README, reproducible setup instructions, experimental results, and résumé-ready description.

---

## 12. Codex Operating Instructions

### Start-of-session checklist

1. Read this `PROGRESS.md`.
2. Inspect the actual repository root and run `git status --short`.
3. Locate the actual active `main.py`, `src/reranker.py`, `src/query_decomposer.py`, `src/hybrid_retriever.py`, current question set, q5 claim mapping, and evaluation scripts.
4. Check whether `main_cleaned.py` exists and whether it is the production entry point or only a backup/alternate file.
5. Inspect current code before applying any fixes described in this document.
6. State the concrete current state in a few bullets, then propose the smallest next action.

### While implementing

- Explain feature background, purpose, design rationale, and evaluation criteria before introducing it.
- Prefer local, understandable edits.
- Do not generate a complete replacement `main.py`, a ZIP, or a collection of artifacts unless explicitly requested.
- Do not change Gold Evidence or chunking to make metrics look better.
- Do not silently change multiple experimental variables.
- Do not claim that an operation succeeded until its actual output confirms it.
- Preserve a useful diagnostic trace so a poor result can be explained rather than triggering blind parameter tuning.

### End-of-step report

After a coding step, report only what is relevant:

1. Files and behavior actually changed.
2. Test or command actually run and its result.
3. Whether the expected behavior was confirmed.
4. Remaining issue, if any.
5. The single next action.

---

## 13. Known Facts vs Unverified Items

### Stable facts / recorded decisions

- Project purpose is research-paper RAG and later Agentic RAG.
- Current corpus is Attention Is All You Need, DCNN, and VGG; no ResNet PDF.
- Mac is the main development machine; Windows RTX 5060 is used for heavier local inference.
- The local Qwen 2B model previously ran successfully on Windows.
- The main retrieval building blocks are Dense, BM25, RRF, and Cross-Encoder reranking.
- The latest production-aligned HyDE comparison showed no improvement for the current five-question evaluation; stop prioritizing HyDE tuning.
- q5 candidate-pool claim coverage is recorded as 4/4 required and 3/3 supplementary, while the global Top-10 context covers only 2/4 required and 0/3 supplementary claims.
- Context Selection is the next technical task.
- The user wants to handwrite code and understand the rationale behind every feature.

### Must be checked in the actual worktree

- Which `main.py` version is active.
- Whether `USE_HYDE` has already been changed to `False`.
- Whether the draft context-selection function still exists and whether its name/body were edited after the uploaded snapshot.
- Whether the selector has been integrated into the main flow.
- Current Git branch and uncommitted changes.
- Current chunk/index counts and actual chunk file version.
- Current evaluation script names, signatures, question set, and claim mapping.
- Whether the Prompt newline escaping issue remains in the active code.
- Whether any post-snapshot test or evaluation has been run.

Do not convert a “must be checked” item into a completed fact without checking it.

---

## 14. One-Paragraph Handoff Summary

Advanced-LLM-RAG is a research-paper RAG project over three PDFs: Attention Is All You Need, DCNN, and VGG. The retrieval core (Dense + BM25 + RRF + Cross-Encoder) and first-pass Rewrite/Decomposition/HyDE experiments exist. The latest production-aligned HyDE ON/OFF results showed no gain, so HyDE should not remain the focus; the uploaded `main(9).py` still showed `USE_HYDE=True`, so inspect the actual worktree before marking the configuration change complete. The main issue is q5 Context Management: the candidate pool covers 4/4 required and 3/3 supplementary claims, but original-query global Top-10 reranking retains only 2/4 required and 0/3 supplementary claims. The user has drafted a query-decomposition-aware selector in an uploaded snapshot, but a review found a list/dictionary misuse and possible score inconsistency; do not assume it has been fixed or integrated. Start by inspecting the actual worktree and Git status, then make the smallest necessary fix, test the selector, compare q5 against the same baseline, and run q1–q5 if the result warrants it. The user prefers to handwrite code and requires background, purpose, design reasoning, and meaningful explanation for every new feature. Do not bulk-generate or package code unless explicitly requested.
