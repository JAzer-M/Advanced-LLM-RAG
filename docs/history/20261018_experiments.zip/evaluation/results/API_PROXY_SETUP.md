# 本地反代：模型选择准备

已收到 Base URL `http://127.0.0.1:7863/v1`，用户确认 OpenAI Chat Completions 协议。

本轮只请求模型列表，没有发送论文或请求生成。服务可响应，未携带认证的 `GET /v1/models` 返回 HTTP 401。尚未取得实际模型名单，因此没有选择模型、验证生成兼容性或比较答案质量。

按 [OpenAI 官方模型列表接口说明](https://developers.openai.com/api/reference/resources/models/methods/list)，模型 ID 用于后续 API 请求的 model 字段。反代列出的 ID 可能是别名；实际路由、可用性、质量和计费以该反代服务为准，不能单凭名称认定。

已创建本地 `api.local.json`，并加入 `.gitignore`。当前 Key 和 model 均为空。用户只需在本地填写 api_key 并保存，暂时保持 model 为空；不要在聊天中发送 Key。也支持已有的 RAG_API_KEY 环境变量。

`list_api_models.py` 使用 Python 标准库读取模型名单，不新增依赖，不输出 Key，不调用生成。配置后可执行：

```powershell
& '.\.venv\Scripts\python.exe' -X utf8 list_api_models.py
```

当前只验证了缺 Key 时会停止，以及本地配置被 Git 忽略；认证成功与生成请求均待配置后验证。当前 main 和本地模型调用没有改变。

下一步：配置 Key → 读取实际模型 ID → 选定一个兼容 Chat Completions 的模型 → 准备最终回答的独立 API 适配 → 用固定 q3/q4 证据和提示词比较。问题分解与检索先保持不变。本准备工作不代表第 6 阶段 C 已完成。
