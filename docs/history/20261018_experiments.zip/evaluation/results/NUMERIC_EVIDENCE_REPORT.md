# 数值证据解析与固定 q5 对照报告

日期：2026-10-18。

**结论：本轮取得了可验证的改善，已停止调参。** 程序完整解析五层卷积规格；简短上下文版本的模型答案正确比较了核心尺寸，不再将 5×5 归给 VGG，引用编号检查通过。模型摘要仍省略部分层号关系和 VGG 的 1×1 配置，不能宣称完整答案验收或整个 RAG 项目已通过。

## 1. 为什么这样改

此前仅补充 HWC 提示规则，没有消除通道宽度混淆、层信息遗漏和主体误归属。程序只检查引文真实，也不能保证其解释正确。

本轮把规则明确的部分移到程序中：识别 `N kernels of size H×W×C`，计算数量、空间尺寸和每个核的通道深度；模型接收已解释的证据，负责综合比较。所有数值来自当前原文，未把 Gold、预期答案或具体架构常量放进生成提示词。

流程：

```text
冻结的原始十个片段
  → 解析明确卷积规格，保留原文位置与引用
  → 保守筛选作者自己的架构描述
  → 程序生成数值表，并组织简短上下文
  → 本地模型综合比较
  → 引用格式检查 + 人工语义验收
```

## 2. 实际改动

- `src/numeric_evidence.py`：纯 Python 数值解析器，无新依赖、无模型调用。支持二维/三维正整数规格及明确英文层号；未知层号、缺失通道保持未知。通过影子文本修复 PDF 断词用于匹配，返回的引文和起止位置仍指向未改动原文。
- `diagnose_q5_numeric_pipeline.py`：独立诊断与证据表渲染。保留冻结输入、原始模型输出、提示词、处理依据、引用检查、代码及输入哈希。程序生成表格中的引用；模型自然语言摘要中的引用另行检查，不能保证所有未来输出格式正确。
- `evaluation/test_numeric_evidence.py`、`evaluation/test_numeric_pipeline.py`：新增真实片段和反例检查；同时运行已有事实诊断检查，共 **21 项通过**。
- 没有改动生产入口 `main.py`、模型 `llm.py`、索引、Gold 或此前原始实验产物。本次得到的是独立可复用解析模块和诊断，不是生产集成完成。

## 3. 程序解析结果

| Document | Layer | Kernel count | Spatial size | Channels per kernel | Citation |
|---|---:|---:|---|---:|---|
| DCNN | 1 | 96 | 11×11 | 3 | [9] |
| DCNN | 2 | 256 | 5×5 | 48 | [3] |
| DCNN | 3 | 384 | 3×3 | 256 | [6] |
| DCNN | 4 | 384 | 3×3 | 192 | [6] |
| DCNN | 5 | 256 | 3×3 | 192 | [6] |

五条规格与原文逐字段一致；第二层的 48、后续层的 256/192 表示每个核的通道深度，不能直接等同于整个输入张量的通道总数。原文引文、字符位置、chunk ID、来源和页码都保存在 JSON 中。

数值本身由解析器获得；表格的文档主体沿用来源标题，并采用“该片段位于 architecture 章节”的有限归属假设。这不是解析器证明了实体归属，遇到混合讨论仍需额外检查。

程序视图保留的 VGG 作者架构原文依据：

> [4] VGG.pdf, page 2: In one of the conﬁgurations we also utilise 1 × 1 convolution ﬁlters, which can be seen as a linear transformation of the input channels (followed by non-linearity).

> [10] VGG.pdf, page 2: The image is passed through a stack of convolutional (conv.) layers, where we use ﬁlters with a very small receptive ﬁeld: 3 × 3 (which is the smallest size to capture the notion of left/right, up/down, center).

因此，即使模型摘要略去了配置例外，证据视图仍保留 VGG 的 1×1 信息。

## 4. 运行过程：失败结果也保留

使用同一个本地 Qwen/Qwen3.5-2B，`do_sample=False`，每次最多 512 新 token；无补前文、无重新检索。共执行三次模型调用：先做两个 JSON 呈现对照，失败后再做一次简短文本呈现。

| 方案 | 模型输出实测 | 结果 |
|---|---|---|
| A：数值表 + 相关原始片段，JSON 呈现 | 仍误归属 VGG 的 5×5；出现不存在于该输入的引用编号 | 失败，保存在 `q5_numeric_pipeline.json` |
| B：同一数值表 + 作者自述筛选，JSON 呈现 | 只回答 VGG 1×1 与 DCNN 3×3，遗漏大量信息 | 失败，同一 JSON 保留 |
| B 简短文本：同一数值表 + 优先架构段落 + 目标句压缩 | 正确表达 VGG 3×3、DCNN 11×11/5×5/3×3；没有 VGG 5×5 误归属，引用格式通过 | 明显改善；原始模型摘要仍不完整 |

最终版本将数值事实改成短句，优先选择每份文档至多两个作者架构段落，并从中保留明确讨论滤波器尺寸的句子。原始十段仍被冻结用于对照，实际提示词使用其中五个不同片段，引用编号保持原编号。重复的 [6] 对应同一片段的三个不同层，并非重建了引用编号。

这次改善来自**解析、保守筛选和上下文重组的组合**。没有证明仅靠数值解析或仅靠主体筛选就能改善答案；两个失败对照正说明这一点。这里的作者自述和架构段落规则是保守启发式，不是通用实体消歧器。

## 5. 最终模型原始摘要

以下内容直接来自 `q5_numeric_pipeline_compact.json`，没有人工改写成标准答案：

Based on the provided context, the differences in convolutional filter sizes between VGG and DCNN are as follows:

*   **VGG** utilizes very small receptive fields, specifically **3 × 3** filters, which is noted as the smallest size to capture spatial notions like left/right, up/down, and center [10].
*   **DCNN** employs a variety of spatial kernel sizes, including **11 × 11** [9], **5 × 5** [3], and **3 × 3** [6].

While both models use 3 × 3 filters, the DCNN architecture in the context specifies a 11 × 11 kernel for the first layer, whereas VGG is characterized by consistently small 3 × 3 kernels.


## 6. 效果验收与边界

| 验收点 | 结果 |
|---|---|
| 五层数量、空间尺寸、每核通道深度 | 程序解析全部正确 |
| 真实引文与原文位置 | 逐条核实一致，包括 PDF 的 `sec- ond` 等断词 |
| 图像尺寸、通道宽度等反例 | 测试中未误识别为卷积核规格 |
| 主体不明的讨论片段 [2] | 保守筛选后未进入最终提示词；没有新增前文去恢复 GoogLeNet |
| 模型比较中的尺寸与引用 | 本例正确使用 11×11、5×5、3×3，引用 [3]、[6]、[9]、[10] 均有效且有对应依据 |
| 逐层文字说明 | 模型明确了第一层，但未把第二层、第三至第五层的对应关系完整写入摘要；程序表格完整保留 |
| VGG 配置例外 | 原文视图保留 1×1；模型摘要遗漏，措辞仍可更谨慎 |
| 通用语义正确性与生产集成 | 未完成，不能据此宣称整体准确率或稳定性提升 |

**两种结果必须区分：** 程序数值记录在当前测试范围内通过；模型摘要取得改善，但按严格的逐层完整性标准仍不是全部通过。没有将它记成“四项必需事实严格验收全部通过”。

最终简短文本方案调用模型一次，耗时 **28.87 秒**（该计时包含首次模型加载，不包括进程启动导入）。前两个方案分别为 34.09 秒、1.31 秒，后者在同一进程内复用已加载模型。任务与输出不同，不能将这些数字作为速度提升基准。各次生成均未触及 512 token 上限。

## 7. 剩余问题如何处理

1. **先把程序表格作为可靠的数值展示层。** 对必须逐层完整呈现的请求，程序渲染全部已解析记录，不能只依赖自由摘要。当前诊断已实现表格；接入生产仍待回归。
2. **扩大解析器覆盖与反例测试。** 当前只支持明确英文卷积规格，不覆盖所有科学数值表达；未知语法不猜。先验证其他论文、其他措辞，再考虑扩展。
3. **主体恢复独立处理。** 作者自述筛选可能排除有价值的第三方讨论，也可能在混合段落中误判。需要通用主体证据和有上限的补前文策略，不能把当前启发式当成已解决实体归属。
4. **摘要完整性需要额外约束。** 后续可让模型只选择已验证事实，再由程序输出关键事实与引用；配置例外也需纳入完整性验收。此项尚未实现。
5. **先做未参与调试的问题回归。** q5 已多次用于设计，本轮结果只证明这个案例及列明测试有所改善，尚无跨问题的泛化结论。

按用户要求，在获得上述改善后停止，没有继续反复调整以追求一次完美输出。

## 8. 复现与产物

```powershell
& '.\.venv\Scripts\python.exe' -X utf8 -m unittest evaluation.test_numeric_evidence evaluation.test_numeric_pipeline evaluation.test_q5_evidence_diagnostic -v
$env:HF_HUB_OFFLINE = '1'
$env:TRANSFORMERS_OFFLINE = '1'
& '.\.venv\Scripts\python.exe' -X utf8 diagnose_q5_numeric_pipeline.py --presentation compact --arm B --output evaluation\results\q5_numeric_pipeline_replay.json
```

脚本拒绝覆盖旧输出。默认参数用于 JSON 双组实验，历史原始提示词以保存的 JSON 为准；复现最终方案请使用上面的显式参数。

- `q5_numeric_pipeline.json`：前两个失败对照及原始提示词、回答。
- `q5_numeric_pipeline_compact.json`：最终方案、完整数值记录、原文位置、上下文、原始回答、引用检查和哈希。
- `numeric_pipeline_acceptance.json`：程序完整性检查及人工语义审阅结论；不是模型自动评分。

本轮沿用 Matt Pocock 的诊断工作流固定反馈信号、保留失败对照，并按鼠鼠实习妙妙工具的改造记录方法说明背景、实现、验收和局限。
