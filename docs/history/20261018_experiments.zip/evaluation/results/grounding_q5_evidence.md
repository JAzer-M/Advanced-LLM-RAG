# q5: 完整证据视图

问题：How do VGG and DCNN differ in their use of convolutional filter sizes?

以下是程序生成的结构化事实与逐字引文，不是模型自由摘要。引文只标明文档出处，不把未验证主体候选变为科学结论。

- Source quotation (VGG.pdf, p.2): “1, and differ only in the depth: from 11 weight layers in the network A (8 conv.” [1][11]
- Source quotation (VGG.pdf, p.2): “and 3 FC layers) to 19 weight layers in the network E (16 conv.” [1][11]
- Source quotation (VGG.pdf, p.4): “Published as a conference paper at ICLR 2015 (22 weight layers) and small convolution ﬁlters (apart from 3 × 3, they also use 1 × 1 and 5 × 5 convolutions).” [2]
- Source quotation (VGG.pdf, p.1): “To this end, we ﬁx other parameters of the architecture, and steadily increase the depth of the network by adding more convolutional layers, which is feasible due to the use of very small (3 × 3) convolution ﬁlters in all layers.” [5]
- Source quotation (VGG.pdf, p.3): “Small-size convolution ﬁlters have been previously used by Ciresan et al.” [7][13]
- Source quotation (VGG.pdf, p.1): “Our main contribution is a thorough evaluation of networks of increasing depth using an architecture with very small (3 × 3) convolution ﬁlters, which shows that a signiﬁcant improvement on the prior-art conﬁgurations can be achieved by pushing the depth to 16–19 weight layers.” [8]
- DCNN: layer 1; spatial 11×11; 96 kernels; 3 channels/kernel. [9][12]
- Source quotation (VGG.pdf, p.2): “) layers, where we use ﬁlters with a very small receptive ﬁeld: 3 × 3 (which is the smallest size to capture the notion of left/right, up/down, center).” [10]
- Source quotation (VGG.pdf, p.2): “layers (the number of channels) is rather small, starting from 64 in the ﬁrst layer and then increasing by a factor of 2 after each max-pooling layer, until it reaches 512.” [1][11]
- Source quotation (VGG.pdf, p.2): “In Table 2 we report the number of parameters for each conﬁguration.” [1][11]
- Source quotation (VGG.pdf, p.4): “Their network topology is, however, more complex than ours, and the spatial reso- lution of the feature maps is reduced more aggressively in the ﬁrst layers to decrease the amount of computation.” [2]
- DCNN: layer 2; spatial 5×5; 256 kernels; 48 channels/kernel. [3][12]
- Source quotation (VGG.pdf, p.2): “In one of the conﬁgurations we also utilise 1 × 1 convolution ﬁlters, which can be seen as a linear transformation of the input channels (followed by non-linearity).” [4]
- Source quotation (VGG.pdf, p.2): “The convolution stride is ﬁxed to 1 pixel; the spatial padding of conv.” [4]
- Source quotation (VGG.pdf, p.2): “the padding is 1 pixel for 3 × 3 conv.” [4]
- Source quotation (VGG.pdf, p.2): “Spatial pooling is carried out by ﬁve max-pooling layers, which follow some of the conv.” [4]
- Source quotation (VGG.pdf, p.1): “In this paper, we address another important aspect of ConvNet architecture design – its depth.” [5]
- DCNN: layer 3; spatial 3×3; 384 kernels; 256 channels/kernel. [6][12]
- DCNN: layer 4; spatial 3×3; 384 kernels; 192 channels/kernel. [6][12]
- DCNN: layer 5; spatial 3×3; 256 kernels; 192 channels/kernel. [6][12]
- Source quotation (VGG.pdf, p.3): “layers have recently been utilised in the “Network in Network” architecture of Lin et al.” [7][13]
- Source quotation (VGG.pdf, p.3): “(2011), but their nets are signiﬁcantly less deep than ours, and they did not evaluate on the large-scale ILSVRC dataset.” [7][13]
- Source quotation (VGG.pdf, p.1): “These ﬁndings were the basis of our ImageNet Challenge 2014 submission, where our team secured the ﬁrst and the second places in the localisa- tion and classiﬁcation tracks respectively.” [8]
- Source quotation (VGG.pdf, p.2): “1 ARCHITECTURE During training, the input to our ConvNets is a ﬁxed-size 224 × 224 RGB image.” [10]
- Source quotation (VGG.pdf, p.2): “The only pre- processing we do is subtracting the mean RGB value, computed on the training set, from each pixel.” [10]

## 引用出处

- [1] VGG.pdf, page 2, chunk 238
- [2] VGG.pdf, page 4, chunk 250
- [3] DCNN.pdf, page 4, chunk 158
- [4] VGG.pdf, page 2, chunk 233
- [5] VGG.pdf, page 1, chunk 224
- [6] DCNN.pdf, page 4, chunk 159
- [7] VGG.pdf, page 3, chunk 248
- [8] VGG.pdf, page 1, chunk 219
- [9] DCNN.pdf, page 4, chunk 157
- [10] VGG.pdf, page 2, chunk 232
- [11] VGG.pdf, page 2, chunk 237
- [12] DCNN.pdf, page 4, chunk 155
- [13] VGG.pdf, page 3, chunk 245
