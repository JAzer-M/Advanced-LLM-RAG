# Context selection evaluation

Run time (Hong Kong): 2026-10-18T10:42:53.388576+08:00

K=10; reserve per sub-query=3; HyDE OFF.
Each question shares one frozen candidate pool across A/B/C.
q6 has no Gold Evidence and is excluded; abstention is not evaluated.
Timing is one observed pass, not a repeated latency benchmark.

| Condition | Precision@10 | Recall@10 | MAP@10 | MRR@10 |
|---|---:|---:|---:|---:|
| A_text_global | 0.2800 | 0.8167 | 0.4283 | 0.6333 |
| B_source_global | 0.3200 | 0.8667 | 0.5784 | 0.7667 |
| C_source_selector | 0.3200 | 0.8667 | 0.5784 | 0.7667 |

| Question | Condition | Recall@10 | AP@10 | RR@10 | q5 required |
|---|---|---:|---:|---:|---|
| q1 | A_text_global | 0.8333 | 0.4333 | 0.5000 | - |
| q1 | B_source_global | 0.8333 | 0.4907 | 1.0000 | - |
| q1 | C_source_selector | 0.8333 | 0.4907 | 1.0000 | - |
| q2 | A_text_global | 1.0000 | 0.1667 | 0.1667 | - |
| q2 | B_source_global | 1.0000 | 1.0000 | 1.0000 | - |
| q2 | C_source_selector | 1.0000 | 1.0000 | 1.0000 | - |
| q3 | A_text_global | 1.0000 | 0.7500 | 1.0000 | - |
| q3 | B_source_global | 1.0000 | 0.5000 | 0.5000 | - |
| q3 | C_source_selector | 1.0000 | 0.5000 | 0.5000 | - |
| q4 | A_text_global | 1.0000 | 0.7042 | 1.0000 | - |
| q4 | B_source_global | 1.0000 | 0.6917 | 1.0000 | - |
| q4 | C_source_selector | 1.0000 | 0.6917 | 1.0000 | - |
| q5 | A_text_global | 0.2500 | 0.0875 | 0.5000 | 2/4 |
| q5 | B_source_global | 0.5000 | 0.2097 | 0.3333 | 4/4 |
| q5 | C_source_selector | 0.5000 | 0.2097 | 0.3333 | 4/4 |

## q1

Why does VGG use small 3x3 convolutional filters?

Sub-queries: ["According to the VGG paper, what is the specific reason VGG uses small 3x3 convolutional filters?", "What is the technical justification for using small 3x3 convolutional filters in VGG networks?"]
Candidate count: 98; Gold coverage: 1.0000
- A_text_global: [219, 224, 32, 232, 281, 158, 250, 245, 233, 246]
- B_source_global: [224, 219, 250, 232, 241, 246, 248, 233, 281, 245]
- C_source_selector: [224, 219, 250, 232, 241, 246, 248, 233, 281, 245]
- C added versus B: []
- C removed versus B: []

## q2

Why does the Transformer use positional encoding?

Sub-queries: []
Candidate count: 60; Gold coverage: 1.0000
- A_text_global: [49, 38, 17, 81, 12, 45, 14, 25, 20, 82]
- B_source_global: [45, 38, 81, 48, 20, 80, 17, 67, 12, 47]
- C_source_selector: [45, 38, 81, 48, 20, 80, 17, 67, 12, 47]
- C added versus B: []
- C removed versus B: []

## q3

Why does the Transformer use scaled dot-product attention?

Sub-queries: []
Candidate count: 60; Gold coverage: 1.0000
- A_text_global: [32, 12, 17, 31, 11, 80, 55, 82, 38, 15]
- B_source_global: [6, 32, 40, 31, 12, 29, 15, 38, 82, 17]
- C_source_selector: [6, 32, 40, 31, 12, 29, 15, 38, 82, 17]
- C added versus B: []
- C removed versus B: []

## q4

How does the DCNN paper use data augmentation to reduce overfitting?

Sub-queries: ["According to the DCNN paper, how does data augmentation reduce overfitting?", "What specific data augmentation techniques are used in the DCNN paper?"]
Candidate count: 113; Gold coverage: 1.0000
- A_text_global: [162, 10, 163, 167, 112, 121, 103, 161, 160, 164]
- B_source_global: [162, 103, 163, 112, 167, 136, 153, 164, 121, 174]
- C_source_selector: [162, 103, 163, 112, 167, 136, 153, 164, 121, 174]
- C added versus B: []
- C removed versus B: []

## q5

How do VGG and DCNN differ in their use of convolutional filter sizes?

Sub-queries: ["According to the VGG paper, what convolutional filter sizes are used?", "According to the DCNN paper, what convolutional filter sizes are used?"]
Candidate count: 100; Gold coverage: 0.8750
- A_text_global: [266, 158, 233, 349, 117, 355, 306, 374, 373, 157]
- B_source_global: [238, 250, 158, 233, 224, 159, 248, 219, 157, 232]
- C_source_selector: [238, 250, 158, 233, 224, 159, 248, 219, 157, 232]
- C added versus B: []
- C removed versus B: []
