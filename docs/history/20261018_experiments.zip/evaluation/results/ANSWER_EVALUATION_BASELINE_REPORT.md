# 第 6 阶段 A：答案与引用基线检查

日期：2026-10-18。**本小步完成了基线收集与审阅，整个第 6 阶段尚未完成。** 保持现有 2B 模型，没有修改 main 的回答行为。

## 为什么做这一步

此前已经能展示证据，也做了检索排序评估，但“引用编号存在”并不说明“引用支持结论”，检索命中率也不能代表最终答案正确率。应先把这两种错误分开记录，再决定最小的修复。

本轮不是扩充题库，也不是继续围绕 q5 改提示词。沿用已有 q1–q6，建立一份可查原文、原始答案和判断依据的基线。

## 本轮实现

- `evaluation/answer_review_protocol.md`：在运行前明确核心事实、引用支撑、无依据新增结论、拒答的检查口径。
- `evaluation/citation_checks.py`：自动检查 `[N]` 的格式、编号范围和是否缺少引用，返回对应原文；不输出通用语义正确性分数。
- `evaluation/run_answer_evaluation.py`：收集主流程答案、上下文、来源和代码指纹，供人工审阅。
- `answer_evaluation_baseline/manual_review.json`：助手逐条审阅的结果，含 15 处代表性答案摘录、模型引用、正确事实对应来源和理由。不是穷尽的原子断言标注，也不是独立专家盲评。

六项针对性格式检查通过：有效编号、越界编号、记录 ID 当引用、小数式编号、应引用但无引用、允许不附引用的拒答。另核对了 15 处审阅摘录确实存在于原始答案，来源编号均可定位。这些检查不替代语义审阅。

## 如何运行与节省重复工作

q1、q3、q4、q6 实际执行 main 的问题分解、检索、融合、重排序及生成。q2、q5 复用上一轮主流程集成记录，先核对问题、main/证据模块以及既有记录的模型、问题集、Gold和数据文件哈希。q5 复用的是上一轮调整解释提示顺序后的最终生成结果，其检索来自上一轮真实主流程，保留原运行来源说明。

本轮四次完整主流程运行共八次语言模型调用，包括四次问题分解和四次回答。没有重复生成 q2/q5，没有将参考答案、Gold 或评审口径输入模型。

新跑的 q1/q3/q4/q6 全链路分别耗时 52.43 / 14.51 / 39.74 / 21.85 秒。包含模型加载与复用差异，仅为运行记录，不构成性能基准。

## 结果

| 问题 | 引用结构 | 内容和引用语义审阅 | 本轮结论 |
|---|---|---|---|
| q1：VGG 为什么用小卷积核 | **失败：完全没有引用** | 参数比较有原文，但没有解释堆叠如何得到更大感受野，也没有说明额外非线性；回答还有较多背景描述 | 严格答案未通过 |
| q2：为什么用位置编码 | 通过 | 无循环/卷积，因此需要注入位置与顺序信息，[1] 直接支持；引用单独成行属于展示问题 | 核心答案通过 |
| q3：为什么缩放点积 | 编号有效 | 核心动机提到了，但把缩放误说成防止解码器向左信息流，并错误比较 additive attention | 严格答案未通过 |
| q4：数据增强怎样缓解过拟合 | 编号有效 | 裁剪/翻转与 RGB PCA 两种方法正确且有依据；额外加入“深度防止过拟合”的无依据因果 | 严格答案未通过 |
| q5：VGG/DCNN 卷积尺寸比较 | 编号有效 | DCNN 层组尺寸表达正确；VGG 1×1 例外遗漏、all layers 概括过度，部分引用不直接支持结论 | 严格答案未通过 |
| q6：论文中无答案的股价问题 | 正确拒答无需引用 | 明确现有材料没有该日期的股价，没有猜价格 | **这个拒答案例通过** |

在五道可回答问题中，四道有格式和范围有效的引用，q1 没有引用；未发现越界编号或本轮支持检查能识别的畸形标记。不能把这个结构结果当作引用准确率。

按预定口径，q2 的核心回答通过；q1、q3、q4、q5 存在明确失败。q6 单例拒答通过，不记作“所有无答案问题都能拒答”，也不据此计算一般拒答能力。

## 两个值得关注的原文对照

### q3：正确编号也可能支撑了错误的机制

模型把缩放因子说成用于防止解码器左向信息流，引用 [3]。但 [3]（chunk 40）描述的是 **masking out ... illegal connections**。真正解释大点积、softmax 小梯度及缩放的，是 [2]（chunk 32）。

因此这不是没检索到材料，而是生成时合并了不同机制，并选了与错误合并相关的引用。[4] 对 additive attention 的说明也不支持“缩放因子等同于 additive attention”的陈述。

### q4：同一片段的相邻事实不自动形成因果

[9]（chunk 121）分别描述过拟合问题，以及移除卷积层会导致性能降低。它没有建立“深度防止过拟合”这个因果关系。模型把两件事合并成解释，尽管引用编号正确，仍然不能接受。

这两例均保留原始答案、对应原文和人工判断，未用模型自评或词汇命中掩盖失败。

## q6 及附带发现

q6 原始结论是：

> The provided context does not contain information about NVIDIA's stock price on October 10, 2026.

它没有生成股价。检索到的是 GPU 捐赠、GTX 580/P100 训练硬件等内容；最终回答识别了材料边界。

同时发现一个独立问题：问题分解额外生成了 **October 10, 2025**，并把原问题重复作为子问题。这改变了查询意图且增加无用检索。最终回答仍使用原始问题，因此本次成功拒答；该附带问题单独记录，本轮没有顺手修改 query decomposer。

## 两个插件和 skill 如何使用

- [鼠鼠实习妙妙工具](C:/Users/J/.codex/plugins/cache/created-by-me-remote/shushu-internship-tool/1.1.0/skills/shushu-internship-tool/SKILL.md)：采用其 modification playbook 的小样本基线、错误分析、真实结果记录方式，区分已完成与待完成，不把失败结果包装成指标提升。
- [Matt Pocock diagnosing-bugs](C:/Users/J/.codex/plugins/cache/created-by-me-remote/matt-pocock-skills/1.0.2/skills/diagnosing-bugs/SKILL.md)：本小步建立能暴露具体错误的反馈记录，先保留失败和原文，下一小步再针对具体原因修复；没有宣称本轮完成全部诊断/修复流程。
- [Karpathy Guidelines](C:/Users/J/.codex/plugins/cache/openai-curated-remote/andrej-karpathy-skills/1.0.0/skills/karpathy-guidelines/SKILL.md)：采用当前可见的该技能，保持修改小、检查与风险相称、复用已有记录，不新增服务、依赖或大规模评测框架。

本轮使用的是技能中的开发方法，没有调用商用模型或外部账户服务。

## 下一步：第 6 阶段 B

先解决最明确、可程序识别的问题：让主流程显式报告缺引用、越界引用和格式错误；必要时对缺引用回答做一次受限修复，保留原始版本，检查是否真的改善。不能仅补上任意编号，也不能把结构检查通过标为语义通过。

随后针对 q3/q4 的机制/因果混淆做小范围修复与同输入对照；若当前模型仍无法可靠改写，应保留原文支撑的表达与明确限制。q6 当前单例已通过，不需要专门硬编码股价拒答规则；后续才补少量真正不同的无答案情境。问题分解的日期漂移另行处理。

当前没有进入 Single-Agent、LangGraph 或 UI 应用阶段，也没有把第 6 阶段标成全部完成。

## 查看与复现

- [逐项人工审阅记录](C:/Users/J/Desktop/Advanced-LLM-RAG/evaluation/results/answer_evaluation_baseline/manual_review.json)
- [q1 原始答案和原文](C:/Users/J/Desktop/Advanced-LLM-RAG/evaluation/results/answer_evaluation_baseline/q1.md)
- [q3 原始答案和原文](C:/Users/J/Desktop/Advanced-LLM-RAG/evaluation/results/answer_evaluation_baseline/q3.md)
- [q4 原始答案和原文](C:/Users/J/Desktop/Advanced-LLM-RAG/evaluation/results/answer_evaluation_baseline/q4.md)
- [q6 原始拒答和原文](C:/Users/J/Desktop/Advanced-LLM-RAG/evaluation/results/answer_evaluation_baseline/q6.md)

运行前确认本地环境与模型可用，在项目目录执行：

```powershell
$env:HF_HUB_OFFLINE = '1'
$env:TRANSFORMERS_OFFLINE = '1'
& '.\.venv\Scripts\python.exe' -X utf8 evaluation/run_answer_evaluation.py
```

重复运行会更新结果目录；若答案或上下文变化，人工审阅须重新进行。人工记录保存了本次答案和上下文指纹。本轮没有修改 main.py、llm.py、检索/解析模块、Gold、问题集和数据；运行前后相关指纹一致。没有提交或推送代码。
