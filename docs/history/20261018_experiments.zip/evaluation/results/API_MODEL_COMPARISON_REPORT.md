# 反代 API 接入与两题对照

本轮收到用户已填好本地 Key 的确认后，成功读取模型列表。Key 未打印，未写入评估记录；配置文件保持 Git 忽略。没有安装额外依赖。

## 模型名单与选择

当前反代可见 20 个 ID，均只代表该服务提供的调用标识，未逐个测试生成：

| 名称分组 | 实际返回的 ID |
|---|---|
| DeepSeek | cn:deepseek-v4-pro、cn:deepseek-v4-flash、cn:deepseek-v4.1-flash |
| GLM | cn:glm-5.3-flash、cn:glm-5.3、cn:glm-5.2、cn:glm-5.1、cn:glm-5v-turbo |
| Kimi | cn:kimi-k3-1、cn:kimi-k2.8-preview、cn:kimi-k2.7、cn:kimi-k2.6 |
| HY | cn:hy3、cn:hy4-preview-f、cn:hy4-preview、cn:hy3-x |
| 其他 | cn:step-5-preview、cn:minimax-m3、cn:space-bunny、cn:auto |

先选 `cn:deepseek-v4-flash` 做初始候选，不遍历全部模型，也不声称它是名单中最强或最便宜的模型。反代的别名、实际路由和价格不能由官方型号名称直接推定。对于固定对照，显式模型 ID 比自动路由标识更便于记录。

## 接入方式

新增 `src/api_llm.py`，使用标准库请求 OpenAI-compatible `GET /models` 和 `POST /chat/completions`；错误不会自动重试或悄悄切换模型。列表脚本复用同一客户端。

main 的最终回答和受限引用修复改用 `generate_final_answer()`；问题分解、改写、HyDE 仍保留原本的本地调用。当前本地配置的 `answer_backend` 是 **local**，所以默认行为仍是本地生成。

配置里已经准备了候选 `model` 和 `chat_options`；只有把本地 `answer_backend` 改成 `api` 才会切换最终回答及其引用修复。本轮没有把 API 设成默认，也没有重新跑 API 版 main 全链路。

配置字段：

```json
{
  "base_url": "http://127.0.0.1:7863/v1",
  "api_key": "在本地保留现有值，不要发到聊天",
  "model": "cn:deepseek-v4-flash",
  "answer_backend": "local",
  "chat_options": {"thinking": {"type": "disabled"}}
}
```

上面是字段说明，不要用示例文字覆盖真实 Key。切换成其他系列时，需要重新确认该反代是否接受对应 chat_options，不能假定所有模型都支持 DeepSeek 参数。

## 两题如何对照

只调用两次生成，分别复用第 6A 阶段 q3/q4 的完整用户提示词与证据，逐字校验提示词和证据台账相同。没有重新检索、分解、加入参考答案、调提示词或执行引用修复。

请求温度 0，输出上限 512 token；请求关闭 DeepSeek thinking。该字段依据 [DeepSeek 官方说明](https://api-docs.deepseek.com/guides/thinking_mode/)，但反代是否原样转发需结合实际响应判断。本次返回的 reasoning token 数均为 0。

调用使用 [Chat Completions 接口形状](https://developers.openai.com/api/reference/resources/chat/subresources/completions/methods/create)。两次服务端返回的 model 都是 `deepseek-v4-flash`，finish_reason 均为 stop，没有截断。返回名称不是对代理上游模型身份的独立证明。

| 问题 | 本地 2B 已知失败 | API 原始输出与人工核对 |
|---|---|---|
| q3：为什么缩放点积 | 将缩放与解码器掩码混淆，错误比较 additive attention，引用不支持新增机制 | 明确大维度→点积幅度增大→softmax 小梯度→逆平方根缩放，[2] 直接支持；效率比较由 [4] 支持；未出现原有机制混淆 |
| q4：数据增强怎样缓解过拟合 | 两种核心方法正确，但额外虚构“深度防止过拟合”因果 | 围绕标签保持变换、平移/翻转、裁剪、RGB PCA 描述；[1][3][8][5] 分别支持；没有深度/dropout 的无关扩展 |

按既定核心事实和直接引用支撑口径，两题 API 草稿本次人工审阅均通过。模型没有额外的校验器改写其输出。

q3 用时 1.78 秒，返回 1258 输入/80 输出 token；q4 用时 2.32 秒，返回 1386 输入/236 输出 token。合计 2644 输入、316 输出 token。这里是 API 请求计时，不能与历史本地主流程的检索/分解/加载总耗时直接比较速度。

服务另返回了自定义 credit 字段，单位未确认，因此不换算为人民币或美元费用，也不据此承诺成本。

## 验证与结论边界

两个后端选择检查与三个既有引用修复回归检查共五项通过。实际 API 调用两次均成功，原始输出保留在相邻 JSON/Markdown，人工审阅及答案指纹在 `api_comparison/review.json`。

**可以确认这个反代目前能调用该候选完成这两题，且这两题比本地 2B 原始答案更可靠。** 这不是全部 20 个模型的排名，也不是一般答案准确率或长期可靠性证明。q1、q5、q6 尚未做 API 对照；不能据此认定第 6 阶段全部通过。

同样的用户提示与证据减少了检索和提示词差异，但不同模型的分词、服务端模板和生成行为仍有差异，本轮不是严格的参数量归因实验。

## 下一步

推荐先把 `cn:deepseek-v4-flash` 保留为有实测依据的候选。若继续采用 API，下一小步对 q1/q5/q6 做同样的固定输入检查，再检查 main 的 API 后端链路；确认后再决定默认切换。保留本地模型作为可选基线，不需要重写检索和证据管理。

API 暂停了原计划围绕本地模型修补 q3/q4 的工作；这两例已看到模型替换带来的直接改善，不再为它们继续堆叠本地规则。

## 文件与复现

- [q3 两种模型原始答案](C:/Users/J/Desktop/Advanced-LLM-RAG/evaluation/results/api_comparison/q3.md)
- [q4 两种模型原始答案](C:/Users/J/Desktop/Advanced-LLM-RAG/evaluation/results/api_comparison/q4.md)
- [人工审阅记录](C:/Users/J/Desktop/Advanced-LLM-RAG/evaluation/results/api_comparison/review.json)

对照入口（会调用两次 API，更新结果目录）：

```powershell
& '.\.venv\Scripts\python.exe' -X utf8 evaluation/compare_api_answers.py --model cn:deepseek-v4-flash
```

模型设置仍在被 Git 忽略的 `api.local.json`，Key 未进入报告、测试或公开配置。未提交或推送代码。
