# 当前进度、模型改善与 API 调用

日期：2026-10-18。

## 本次改动

按用户要求，将 `api.local.json` 的模型改为 `cn:deepseek-v4.1-flash`，保留已填写的 Key。同步空白配置模板、README、PROGRESS 和 PyCharm 指南。移除 Kimi 的请求选项，改用 thinking disabled、temperature=0、max_tokens=4096。动机是沿用已有 API 封装切换模型，避免改动已经工作的检索和证据逻辑。

本次没有发 API 请求、列模型、健康探测或运行任何测试。因此只确认配置已修改，不声明 v4.1 的接口兼容性、回答效果或服务可用性已经验证。

## 整体阶段

| 阶段 | 当前状态 |
|---|---|
| 1–4：PDF、索引、混合检索与重排、分块/元数据、查询优化 | 已有实现与首轮实验；主流程关闭 HyDE 和 Multi-query |
| 5：Context Management / 证据管理 | 首版已接入 main；保留 Top-10 原文、数字证据、有限主体上下文和统一引用编号 |
| 6：Citation Validation 与 Answer-level Evaluation | 引用结构检查和最多一次修复已接入；已有六题基线与 API 对比，首轮评估可收尾，有明确局限 |
| 7：Single-Agent 工作流 | 下一步，尚未实现 |
| 8：LangGraph 编排 | 待开始 |
| 9：Streamlit 或 Gradio 演示 | 待开始，选择一种即可 |
| 10：最终 README、复现实验说明、简历描述 | 待最终整理；已有文档是开发期版本 |

第 6 阶段的“首轮完成”不等于任意答案都已通过语义校验。现有引用检查能发现格式、编号和来源存在性问题，不能可靠判断任意陈述是否被引用原文蕴含。q6 是一个已通过的无答案案例，尚不能代表普遍拒答能力。

## 换模型后实际观察到什么

以下来自保存的历史实验，本次没有重新测量。

| 对比 | 观察结果 | 适用范围 |
|---|---|---|
| 本地 2B → `cn:deepseek-v4-flash` | q3 正确解释 attention 缩放，未再混淆 decoder mask / additive attention；q4 正确聚焦裁剪翻转与 RGB PCA，未再编造网络深度导致不过拟合的因果 | 只比较两题，固定原提示词和证据 |
| 本地 2B → `cn:kimi-k3-1` | q1 补齐核心理由；q2 核心解释正确；q3/q4 上述错误消失；q5 五层卷积参数和 VGG 1×1 例外更完整；q6 正确拒答，分解不再擅加 2025 年 | 六题实际 main 运行；q1/q2/q3/q5 最终提示词和 Top-10 与旧版相同，q4/q6 的分解改变检索，另做 q4 旧提示词对照 |
| 数字和主体抽取回归（Kimi） | 第一、二、四/五层参数，以及片段未知主体、补上下文后 GoogLeNet 归属，共五个用例通过 | 窄范围回归；2B 经过此前修正也能通过这些抽取用例 |
| 当前 `cn:deepseek-v4.1-flash` | 仅配置切换 | 按用户要求未测试，不能继承上述成绩 |

Kimi 阶段 34 个相关组件检查通过，六题 main 共 12 次成功 API 调用，未触发引用修复。q5 仍有过于绝对的概括和上下文未给出的 AlexNet 别名，因此严格逐句证据审核未全通过。历史过程遇到两次 HTTP 503，保存了失败记录；程序没有自动回退本地模型或无限重试。不将这些小样本转成整体准确率，也不宣称提速或泛化问题全部解决。

这说明生成模型是之前错误的重要来源之一；检索、证据组织和模型参数配置也影响结果，不能仅用参数量解释全部差异。

历史依据：[DeepSeek 两题对比](API_MODEL_COMPARISON_REPORT.md)、[Kimi 主流程检查](KIMI_MIGRATION_REPORT.md)、[2B 回答基线](ANSWER_EVALUATION_BASELINE_REPORT.md)。

## 我们如何调用 API

```text
PyCharm 启动 main.py
  → 本地检索、重排、证据整理（问题分解也可请求 API）
  → src.api_llm.generate_final_answer / llm.generate_answer
  → src.api_llm.chat_completion
  → POST http://127.0.0.1:7863/v1/chat/completions
  → 本机反代转发模型请求
  → 读取 choices[0].message.content
  → 引用检查，必要时最多一次引用修复
```

`src/api_llm.py` 用 Python 标准库 urllib 发送请求。配置来自项目根目录的 `api.local.json`；环境变量 `RAG_API_KEY` 可覆盖文件中的 Key。请求头携带 `Authorization: Bearer <Key>`，JSON 正文包含 model、messages、stream=false 和 chat_options。无需在 PyCharm AI 插件里配置模型，也无需安装额外 SDK。

PyCharm 只是运行 Python 的工具。保持反代启动，使用项目 `.venv` 解释器运行 main.py 即可正常提问；本次不要求用户额外跑评估。修改模型时同时调整其支持的参数。所有启用的生成调用共享该配置，主流程不再加载本地 Qwen；embedding 和 reranker 仍在本地 CPU 上运行。

完整运行与故障说明：[PyCharm API 接入指南](../../docs/PYCHARM_API_GUIDE.md)。

## 下一步的动机与范围

开始一个最小、有次数限制的 Single-Agent：检索后判断证据是否足够；不足时最多补检索一次；仍不足则明确拒答或只回答有证据的部分。记录判断、补检索与回答依据。API 连接失败单独报服务错误，不能当作“论文里没有答案”。

动机是让系统能根据证据采取下一步行动。先把这个闭环做清楚，再用 LangGraph 表达节点和状态，最后增加演示页面。当前请求仅切换模型并说明进度，尚未开始这部分实现。
