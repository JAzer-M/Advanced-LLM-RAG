# 完整证据附件

- Source quotation (Attention is all you need.pdf, p.5): “5 Positional Encoding Since our model contains no recurrence and no convolution, in order for the model to make use of the order of the sequence, we must inject some information about the relative or absolute position of the tokens in the sequence.” [1]
- Source quotation (Attention is all you need.pdf, p.5): “To this end, we add "positional encodings" to the input embeddings at the” [1]
- Source quotation (Attention is all you need.pdf, p.5): “3 Applications of Attention in our Model The Transformer uses multi-head attention in three different ways: • In "encoder-decoder attention" layers, the queries come from the previous decoder layer, and the memory keys and values come from the output of the encoder.” [2]
- Source quotation (Attention is all you need.pdf, p.5): “This allows every position in the decoder to attend over all positions in the input sequence.” [2]
- Source quotation (Attention is all you need.pdf, p.5): “This mimics the typical encoder-decoder attention mechanisms in sequence-to-sequence models such as [31, 2, 8].” [2]
- Source quotation (Attention is all you need.pdf, p.9): “7 Conclusion In this work, we presented the Transformer, the ﬁrst sequence transduction model based entirely on attention, replacing the recurrent layers most commonly used in encoder-decoder architectures with multi-headed self-attention.” [3]
- Source quotation (Attention is all you need.pdf, p.9): “For translation tasks, the Transformer can be trained signiﬁcantly faster than architectures based on recurrent or convolutional layers.” [3]
- Source quotation (Attention is all you need.pdf, p.9): “On both WMT 2014 English-to-German and WMT 2014 English-to-French translation tasks, we achieve a new state of the art.” [3]
- Source quotation (Attention is all you need.pdf, p.6): “In this work, we use sine and cosine functions of different frequencies: PE(pos,2i) = sin(pos/100002i/dmodel) PE(pos,2i+1) = cos(pos/100002i/dmodel) where pos is the position and i is the dimension.” [4]
- Source quotation (Attention is all you need.pdf, p.6): “That is, each dimension of the positional encoding corresponds to a sinusoid.” [4]
- Source quotation (Attention is all you need.pdf, p.6): “The wavelengths form a geometric progression from 2π to 10000 · 2π.” [4]
- Source quotation (Attention is all you need.pdf, p.2): “The Transformer follows this overall architecture using stacked self-attention and point-wise, fully connected layers for both the encoder and decoder, shown in the left and right halves of Figure 1, respectively.” [5]
- Source quotation (Attention is all you need.pdf, p.9): “This suggests that determining compatibility is not easy and that a more sophisticated compatibility function than dot product may be beneﬁcial.” [6]
- Source quotation (Attention is all you need.pdf, p.9): “We further observe in rows (C) and (D) that, as expected, bigger models are better, and dropout is very helpful in avoiding over-ﬁtting.” [6]
- Source quotation (Attention is all you need.pdf, p.9): “In row (E) we replace our sinusoidal positional encoding with learned positional embeddings [8], and observe nearly identical results to the base model.” [6]
- Source quotation (Attention is all you need.pdf, p.2): “To the best of our knowledge, however, the Transformer is the ﬁrst transduction model relying entirely on self-attention to compute representations of its input and output without using sequence- aligned RNNs or convolution.” [7]
- Source quotation (Attention is all you need.pdf, p.2): “In the following sections, we will describe the Transformer, motivate self-attention and discuss its advantages over models such as [14, 15] and [8].” [7]
- Source quotation (Attention is all you need.pdf, p.7): “4 Regularization We employ three types of regularization during training: Residual Dropout We apply dropout [27] to the output of each sub-layer, before it is added to the sub-layer input and normalized.” [8]
- Source quotation (Attention is all you need.pdf, p.7): “In addition, we apply dropout to the sums of the embeddings and the positional encodings in both the encoder and decoder stacks.” [8]
- Source quotation (Attention is all you need.pdf, p.2): “In this work we propose the Transformer, a model architecture eschewing recurrence and instead relying entirely on an attention mechanism to draw global dependencies between input and output.” [9]
- Source quotation (Attention is all you need.pdf, p.2): “The Transformer allows for signiﬁcantly more parallelization and can reach a new state of the art in translation quality after being trained for as little as twelve hours on eight P100 GPUs.” [9]
- Source quotation (Attention is all you need.pdf, p.6): “Layer Type Complexity per Layer Sequential Maximum Path Length Operations Self-Attention O(n2 · d) O(1) O(1) Recurrent O(n · d2) O(n) O(n) Convolutional O(k · n · d2) O(1) O(logk(n)) Self-Attention (restricted) O(r · n · d) O(1) O(n/r) bottoms of the encoder and decoder stacks.” [10][1]
- Source quotation (Attention is all you need.pdf, p.6): “The positional encodings have the same dimension dmodel as the embeddings, so that the two can be summed.” [10][1]
- Source quotation (Attention is all you need.pdf, p.6): “There are many choices of positional encodings, learned and ﬁxed [8].” [10][1]

## 引用出处

- [1] Attention is all you need.pdf, p.5 (chunk 45)
- [2] Attention is all you need.pdf, p.5 (chunk 38)
- [3] Attention is all you need.pdf, p.9 (chunk 81)
- [4] Attention is all you need.pdf, p.6 (chunk 48)
- [5] Attention is all you need.pdf, p.2 (chunk 20)
- [6] Attention is all you need.pdf, p.9 (chunk 80)
- [7] Attention is all you need.pdf, p.2 (chunk 17)
- [8] Attention is all you need.pdf, p.7 (chunk 67)
- [9] Attention is all you need.pdf, p.2 (chunk 12)
- [10] Attention is all you need.pdf, p.6 (chunk 47)