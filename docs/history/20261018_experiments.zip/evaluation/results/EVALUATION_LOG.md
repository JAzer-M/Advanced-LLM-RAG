# Advanced-LLM-RAG 实验评估档案

-   **整理日期：** 2026-10-17
-   **用途：** 保存项目中分散在 `main.py`、通用检索评估、HyDE
    评估、Production Top-K 评估以及历史 Chunking
    实验中的结果，避免混淆脚本、Gold Evidence 和检索流程。
-   **重要约定：**
    保留已知数值与可确认的实验口径；来源不完整或版本不一致的地方明确标注，不猜测缺失数据。

## 0. 快速索引

  -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
  编号           实验 / 脚本                                           性质                                                                 主要结果       可比性
  -------------- ----------------------------------------------------- -------------------------------------------------------------------- -------------- --------------------------------------
  A              `main.py`                                             定性检索与生成 smoke test                                            §1             不产生整体检索指标

  B              `evaluation/run_evaluation.py`（历史输出/上传源码名   Dense、BM25、Hybrid、Reranker、Rewrite、Multi-Query、Decomposition   §2             仅与相同问题集、Gold Evidence
                 `run_evaluation(2).py`）                                                                                                                  版本严格可比

  C              `evaluation/run_hyde_evaluation.py`                   Baseline、HyDE、RRF(Dense + HyDE Dense)、Union + Cross-Encoder       §3             最新 HyDE
                                                                                                                                                           版本内部可比；与其他脚本不可直接比较

  D              `run_production_topk_evaluation.py`                   `USE_MULTI_QUERY=False/True` 的 Production Top-K 对照                §4             需要以源码核实开关语义

  E1             330 chunks 早期检索基准                               Dense、BM25、Hybrid、Hybrid + Reranker                               §5.1           历史基准

  E2             Fixed / Recursive / Semantic Chunking 对照            多种分块和检索方法                                                   §5.2           历史对照，需核对索引和问题集版本

  E3             另一轮早期五题评估                                    Dense、BM25、Hybrid、Hybrid + Reranker                               §5.3           单独保存

  F              Gold Evidence Coverage 诊断                           检查 Gold Chunk 是否被找到                                           §6             诊断数据，不等同于整体检索指标
  -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

### 证据等级

-   **较高：** 已读取源码和对应控制台输出可以互相核对。
-   **中等：**
    有较完整的控制台输出，但未取得与该次运行完全对应的源码快照。
-   **历史记录：**
    来自之前的项目进度记录；应保留，但复现实验前不能视为当前代码的最新结果。

## 1. `main.py`：定性检索与生成测试

**测试问题：** `Why does VGG use small 3×3 convolutional filters?`

### 已观察到的结果

-   检索 Top-10 中包含 VGG 相关证据：3×3
    感受野可捕捉局部空间关系；堆叠多个 3×3
    卷积层可以增加网络深度；在相同通道数的特定假设下，三层 3×3
    卷积的权重数量可写为 `27C²`，单层 7×7 卷积可写为 `49C²`。
-   Top-10 中也出现过一个与 VGG 问题无关的 Transformer 片段。
-   Qwen 成功生成带 `[1]`、`[2]` 等引用标记的答案。
-   日志中的查询：
    -   Original: `Why does VGG use small 3x3 convolutional filters?`
    -   Rewritten: `VGG small 3x3 convolutional filter sizes`
-   分享过的两次运行中，最终 Top-10
    和生成答案基本相同，未观察到明显变化。

### 解释与限制

这属于**定性 smoke
test**，证明检索---生成链路能够运行，但不是整体检索评估。不能据此计算
Precision@K、Recall@K、MAP 或 MRR，也不能仅凭一次输出判断 Rewrite
有无普遍收益。项目进度记录显示 `main.py` 的 Rewrite 当前设为
`False`；这不自动更改其他评估脚本的独立开关。

**证据等级：中等。**
依据近期控制台输出和项目进度记录；本档案没有重新运行 `main.py`。

## 2. 通用检索评估：`run_evaluation.py`

### 2.1 可确认的配置

根据已读取的 `run_evaluation(2).py` 源码：

-   索引：`data/processed/faiss_semantic.index`
-   Chunk 文件：`data/processed/chunks_semantic.json`
-   `FINAL_K = 5`
-   `CANDIDATE_K = 20`
-   `RRF_TOP_K = 20`
-   `RRF_K = 60`
-   `ENABLE_REWRITING = True`
-   `ENABLE_DECOMPOSITION = True`
-   Reranker：`BAAI/bge-reranker-base`
-   Reranker device：`cpu`
-   q6 因无 Gold Evidence 被跳过；整体统计为五道有效问题。

Decomposition 若判断"不需要拆解"，就会回退使用原始 Hybrid + Reranker
结果。因此，整体 Decomposition
分数不代表每一道题都实际执行了子查询拆解。

### 2.2 整体 Top-5 结果

指标顺序：Mean Precision@5 / Mean Recall@5 / MAP@5 / MRR@5。

  -----------------------------------------------------------------------------
  方法                 Precision@5       Recall@5          MAP@5          MRR@5
  ----------------- -------------- -------------- -------------- --------------
  Dense                     0.2400         0.3733         0.1961         0.4667

  BM25                      0.2400         0.4167         0.3856         0.6000

  Hybrid                    0.2800         0.5667         0.4367         0.7000

  Hybrid + Reranker         0.4000         0.6900         0.4119         0.5800

  Rewritten                 0.4000         0.6967         0.4349         0.7400
  Hybrid + Reranker                                              

  Multi-Query +             0.3600         0.6500         0.4039         0.5400
  Reranker                                                       

  Decomposition +           0.4000         0.6900         0.4439         0.7400
  Hybrid + Reranker                                              
  -----------------------------------------------------------------------------

### 2.3 本轮日志中的逐题结果

以下为已保存日志可恢复的逐题数值，格式为
`P@5 / R@5 / AP@5 / RR@5`。Chunk ID 只在对应 chunks 文件版本内有意义。

#### q1 --- Why does VGG use small 3×3 convolutional filters?

  ---------------------------------------------------------------------------------------------------
  方法              Retrieved IDs                          P@5          R@5         AP@5         RR@5
  ----------------- ----------------------------- ------------ ------------ ------------ ------------
  Dense             `[357, 233, 246, 349, 158]`         0.2000       0.1667       0.0556       0.3333

  BM25              `[232, 250, 224, 241, 219]`         0.4000       0.3333       0.2778       1.0000

  Hybrid            `[246, 158, 250, 233, 281]`         0.4000       0.3333       0.2333       1.0000

  Hybrid + Reranker `[219, 224, 232, 281, 158]`         0.6000       0.5000       0.3194       0.5000

  Decomposition +   `[219, 224, 232, 281, 158]`         0.6000       0.5000       0.3194       0.5000
  Hybrid + Reranker                                                                      

  Rewritten         `[219, 224, 232, 158, 250]`         0.4000       0.3333       0.1944       0.5000
  Hybrid + Reranker                                                                      

  Multi-Query +     `[219, 224, 232, 281, 158]`         0.6000       0.5000       0.3194       0.5000
  Reranker                                                                               
  ---------------------------------------------------------------------------------------------------

本题触发
Decomposition。日志子查询：`According to the VGG paper, what is the specific reason VGG uses small 3x3 convolutional filters?`；`What is the technical justification for using small 3x3 convolutional filters in VGG networks?`

#### q2 --- Why does the Transformer use positional encoding?

Gold IDs：`[45]`

  -----------------------------------------------------------------------------------------------
  方法              Retrieved IDs                      P@5          R@5         AP@5         RR@5
  ----------------- ------------------------- ------------ ------------ ------------ ------------
  Dense             `[81, 20, 17, 25, 38]`          0.0000       0.0000       0.0000       0.0000

  BM25              `[45, 48, 80, 78, 166]`         0.2000       1.0000       1.0000       1.0000

  Hybrid            `[45, 17, 78, 81, 12]`          0.2000       1.0000       1.0000       1.0000

  Hybrid + Reranker `[38, 17, 81, 12, 45]`          0.2000       1.0000       0.2000       0.2000

  Decomposition +   `[38, 17, 81, 12, 45]`          0.2000       1.0000       0.2000       0.2000
  Hybrid + Reranker                                                                  

  Rewritten         `[38, 17, 81, 12, 45]`          0.2000       1.0000       0.2000       0.2000
  Hybrid + Reranker                                                                  

  Multi-Query +     `[38, 17, 81, 12, 45]`          0.2000       1.0000       0.2000       0.2000
  Reranker                                                                           
  -----------------------------------------------------------------------------------------------

本题 Decomposition 未触发，回退使用原始 Hybrid + Reranker。Rewrite
query：`Transformer positional encoding`。

#### q3 --- Why does the Transformer use scaled dot-product attention?

Gold IDs：`[31, 32]`

  ----------------------------------------------------------------------------------------------
  方法              Retrieved IDs                     P@5          R@5         AP@5         RR@5
  ----------------- ------------------------ ------------ ------------ ------------ ------------
  Dense             `[15, 31, 17, 27, 32]`         0.4000       1.0000       0.4500       0.5000

  BM25              `[27, 29, 6, 40, 35]`          0.0000       0.0000       0.0000       0.0000

  Hybrid            `[27, 31, 6, 29, 32]`          0.4000       1.0000       0.4500       0.5000

  Hybrid + Reranker `[32, 12, 17, 31, 38]`         0.4000       1.0000       0.7500       1.0000

  Decomposition +   `[32, 12, 17, 31, 38]`         0.4000       1.0000       0.7500       1.0000
  Hybrid + Reranker                                                                 

  Rewritten         `[32, 12, 17, 31, 11]`         0.4000       1.0000       0.7500       1.0000
  Hybrid + Reranker                                                                 

  Multi-Query +     `[32, 12, 17, 31, 11]`         0.4000       1.0000       0.7500       1.0000
  Reranker                                                                          
  ----------------------------------------------------------------------------------------------

本题 Decomposition 未触发。Rewrite
query：`Transformer scaled dot-product attention mechanism`。

#### q4 --- How does the DCNN paper use data augmentation to reduce overfitting?

Gold IDs：`[162, 163, 164, 167]`

  ---------------------------------------------------------------------------------------------------
  方法              Retrieved IDs                          P@5          R@5         AP@5         RR@5
  ----------------- ----------------------------- ------------ ------------ ------------ ------------
  Dense             `[162, 161, 361, 167, 121]`         0.4000       0.5000       0.3750       1.0000

  BM25              `[162, 163, 174, 103, 167]`         0.6000       0.7500       0.6500       1.0000

  Hybrid            `[162, 167, 160, 103, 121]`         0.4000       0.5000       0.5000       1.0000

  Hybrid + Reranker `[162, 163, 167, 121, 103]`         0.6000       0.7500       0.7500       1.0000

  Decomposition +   `[162, 163, 167, 121, 103]`         0.6000       0.7500       0.7500       1.0000
  Hybrid + Reranker                                                                      

  Rewritten         `[162, 163, 167, 121, 103]`         0.6000       0.7500       0.7500       1.0000
  Hybrid + Reranker                                                                      

  Multi-Query +     `[162, 163, 167, 121, 103]`         0.6000       0.7500       0.7500       1.0000
  Reranker                                                                               
  ---------------------------------------------------------------------------------------------------

本题触发 Decomposition；候选池去重前 60、去重后
39。日志子查询：`According to the DCNN paper, how does data augmentation reduce overfitting?`；`What specific data augmentation techniques are used in the DCNN paper?`

#### q5 --- How do VGG and DCNN differ in their use of convolutional filter sizes?

本轮 Gold IDs：`[157, 158, 159, 241, 246]`。

  ---------------------------------------------------------------------------------------------------
  方法              Retrieved IDs                          P@5          R@5         AP@5         RR@5
  ----------------- ----------------------------- ------------ ------------ ------------ ------------
  Dense             `[357, 246, 373, 245, 233]`         0.2000       0.2000       0.1000       0.5000

  BM25              `[183, 255, 311, 164, 117]`         0.0000       0.0000       0.0000       0.0000

  Hybrid            `[250, 238, 304, 357, 183]`         0.0000       0.0000       0.0000       0.0000

  Hybrid + Reranker `[233, 117, 355, 373, 157]`         0.2000       0.2000       0.0400       0.2000

  Decomposition +   `[158, 233, 349, 117, 355]`         0.2000       0.2000       0.2000       1.0000
  Hybrid + Reranker                                                                      

  Rewritten         `[158, 233, 374, 373, 157]`         0.4000       0.4000       0.2800       1.0000
  Hybrid + Reranker                                                                      

  Multi-Query +     `[233, 117, 355, 374, 373]`         0.0000       0.0000       0.0000       0.0000
  Reranker                                                                               
  ---------------------------------------------------------------------------------------------------

本题触发 Decomposition；候选池去重前 60、去重后 35。子查询分别询问 VGG
与 DCNN 论文中的卷积核尺寸。

### 2.4 这轮实验的解读与限制

-   Hybrid 相较 Dense 的 Recall@5 从 0.3733 提升到 0.5667。
-   Hybrid + Reranker 的 Precision@5 为 0.4000、Recall@5 为 0.6900。
-   Rewritten Hybrid + Reranker 的 Recall@5 为 0.6967，只比未改写的
    Hybrid + Reranker 略高。
-   Decomposition + Hybrid + Reranker 的 MAP@5 为
    0.4439，是该轮七种方法中最高；MRR@5 为 0.7400，与 Rewrite 并列最高。
-   Multi-Query + Reranker 在这轮的整体指标低于 Rewrite 和
    Decomposition。
-   本日志的 q3 是 scaled dot-product attention，q4 是 data
    augmentation；项目后来整理过其他问题集版本（如 q3 Multi-Head
    Attention、q4 Local Response Normalization）。不可假定本轮与当前
    `evaluation/questions.json` 相同。

**证据等级：较高。**
有已读取的脚本与对应控制台输出；当前磁盘上的问题集是否与该轮一致仍需核对。

## 3. HyDE 独立实验：`run_hyde_evaluation.py`

### 3.1 最新一版配置

-   Semantic index：`faiss_semantic.index`
-   Chunks：`chunks_semantic.json`
-   `FINAL_K = 5`
-   `RETRIEVAL_CANDIDATE_K = 60`
-   `RRF_K = 60`
-   诊断 K：`(5, 10, 20)`
-   Reranker：`BAAI/bge-reranker-base`
-   设备：CPU
-   五道有效问题；q6 因无 Gold Evidence 跳过。

### 3.2 四种方法的真实含义

1.  **Baseline：** 原始问题 → Dense Retrieval。
2.  **HyDE：** 生成假设性文档 → 使用文档做 Dense Retrieval。
3.  **RRF Fusion：** 融合原始查询 Dense 结果与 HyDE 文档 Dense 结果。
4.  **Union + Cross-Encoder：** 合并两路 Dense
    候选、去重，再用原始问题对候选重排序。

**重要：** 第三种方法融合的是 **原始查询 Dense + HyDE Dense**。虽然 RRF
函数参数名可能是 `bm25_results`，第二路实际不是 BM25，因此它不是标准的
Dense + BM25 Hybrid Search。

### 3.3 最新一版整体 Top-5 指标

指标顺序：Precision@5 / Recall@5 / MAP@5 / MRR@5。

  方法                                    P@5   Recall@5    MAP@5    MRR@5
  ---------------------------------- -------- ---------- -------- --------
  Baseline                             0.2800     0.3833   0.2011   0.4667
  HyDE                                 0.2800     0.5333   0.2211   0.5000
  RRF Fusion（Dense + HyDE Dense）     0.2800     0.5250   0.2358   0.4167
  Union + Cross-Encoder                0.2800     0.3250   0.2597   0.6000

解读：HyDE Recall@5 比 Baseline 高 0.1500；RRF Fusion 的 MAP@5 为
0.2358，高于 Baseline 的 0.2011；Union + Cross-Encoder 的 MAP@5/MRR@5 为
0.2597/0.6000，但 Recall@5 只有 0.3250。重排序可改善前部排序指标，但在
Top-5 截断处不一定保留更多 Gold Evidence。

### 3.4 Union + Cross-Encoder 的 Top-K 诊断

  指标                Top-5   Top-10   Top-20
  ---------------- -------- -------- --------
  Mean Precision     0.2800   0.2600   0.1700
  Mean Recall        0.3250   0.7667   0.8750
  MAP                0.2597   0.3714   0.4053
  MRR                0.6000   0.6250   0.6250

这是同一份重排序列表在不同 K 值处的截断评估，不是三种独立算法。

### 3.5 最新 HyDE 运行的问题集与 Gold IDs

日志中的问题集版本如下；它与项目后来整理的其他问题集版本不完全相同。

  --------------------------------------------------------------------------------------------
  Question                日志中的问题            Gold Chunk IDs
  ----------------------- ----------------------- --------------------------------------------
  q1                      Why does VGG use small  `[224, 232, 242, 245, 246, 281]`
                          3×3 convolutional       
                          filters?                

  q2                      Why does the            `[45]`
                          Transformer use         
                          positional encoding?    

  q3                      Why does the            `[31, 32]`
                          Transformer use scaled  
                          dot-product attention?  

  q4                      How does the DCNN paper `[162, 163, 164, 167]`
                          use data augmentation   
                          to reduce overfitting?  

  q5                      How do VGG and DCNN     `[157, 158, 159, 224, 241, 245, 246, 280]`
                          differ in their use of  
                          convolutional filter    
                          sizes?                  

  q6                      What was NVIDIA's stock 无 Gold Evidence，跳过
                          price on October 10,    
                          2026?                   
  --------------------------------------------------------------------------------------------

### 3.6 Union + Cross-Encoder：逐题 Recall 与候选池

  Question     去重后的候选数   Recall@5   Recall@10   Recall@20
  ---------- ---------------- ---------- ----------- -----------
  q1                       88     0.5000      0.8333      1.0000
  q2                       77     0.0000      1.0000      1.0000
  q3                       81     0.5000      1.0000      1.0000
  q4                      101     0.5000      0.7500      0.7500
  q5                       67     0.1250      0.2500      0.6250

### 3.7 HyDE 较早版本结果

历史版本的 Prompt、Gold Evidence
和代码可能不同。没有固定评估条件之前，不应直接比较版本间的分数高低。

#### 历史版本 A（更早日志，具体配置未完全核实）

  方法            P@5   Recall@5    MAP@5    MRR@5
  ---------- -------- ---------- -------- --------
  Baseline     0.2400     0.3733   0.1961   0.4667
  HyDE         0.1600     0.4333   0.3111   0.3667

#### 历史版本 B（Prompt 再次修改前）

  方法                                    P@5   Recall@5    MAP@5    MRR@5
  ---------------------------------- -------- ---------- -------- --------
  Baseline                             0.2800     0.3833   0.2011   0.4667
  HyDE                                 0.2800     0.5083   0.3469   0.4333
  RRF Fusion（Dense + HyDE Dense）     0.2800     0.5333   0.2267   0.3567

#### 最新版本（复列便于核对）

  方法                                    P@5   Recall@5    MAP@5    MRR@5
  ---------------------------------- -------- ---------- -------- --------
  Baseline                             0.2800     0.3833   0.2011   0.4667
  HyDE                                 0.2800     0.5333   0.2211   0.5000
  RRF Fusion（Dense + HyDE Dense）     0.2800     0.5250   0.2358   0.4167
  Union + Cross-Encoder                0.2800     0.3250   0.2597   0.6000

历史版本 B 的 MAP@5 为 0.3469，高于最新版本的 0.2211；但这不能证明旧
Prompt 更好，因为 Gold
Evidence、问题集、候选设置与实现版本没有被证明完全相同。

**证据等级：**
最新版较高；旧版本中等/历史记录。最新版脚本与日志已检索读取；旧版参数无法全部还原。

## 4. Production Top-K Evaluation

脚本名：`run_production_topk_evaluation.py`。

### 4.1 日志中共同出现的配置

-   `RETRIEVAL_TOP_K = 60`
-   `RRF_TOP_K = 60`
-   `RRF_K = 60`
-   最终 K：5、10、20
-   五道有效问题
-   使用 Semantic chunks 和 BGE Cross-Encoder
-   对照开关：`USE_MULTI_QUERY=False` 与 `USE_MULTI_QUERY=True`
-   q1、q4、q5 触发 Decomposition；q2、q3 不触发。

### 4.2 `USE_MULTI_QUERY = False`

  指标                Top-5   Top-10   Top-20
  ---------------- -------- -------- --------
  Mean Precision     0.3600   0.2800   0.1500
  Mean Recall        0.4750   0.8167   0.8500
  MAP                0.3367   0.4283   0.4450
  MRR                0.6000   0.6333   0.6333

### 4.3 `USE_MULTI_QUERY = True`

  指标                Top-5   Top-10   Top-20
  ---------------- -------- -------- --------
  Mean Precision     0.3600   0.2800   0.1500
  Mean Recall        0.4750   0.8167   0.8500
  MAP                0.3367   0.4236   0.4402
  MRR                0.6000   0.6286   0.6286

### 4.4 开启减去关闭的差值

  指标                Top-5    Top-10    Top-20
  ---------------- -------- --------- ---------
  Precision 差值     0.0000    0.0000    0.0000
  Recall 差值        0.0000    0.0000    0.0000
  MAP 差值           0.0000   -0.0047   -0.0048
  MRR 差值           0.0000   -0.0047   -0.0047

在这组结果中，开启 Multi-Query 没有带来 Recall 提升，Top-10/20 的 MAP 与
MRR 还有轻微下降。当前结果不支持仅为提高整体检索指标而默认开启它。

**配置语义保留说明：** 这里保留日志中的 `USE_MULTI_QUERY`
原名。未将其直接等同于 `main.py` 的 Rewrite
开关；要确认它如何构造查询和候选池，需要检查当次运行的源码。

### 4.5 已记录的逐题 Gold Rank 诊断（关闭 Multi-Query 日志）

以下是历史日志中的排名记录，不在此重新计算指标。

  -----------------------------------------------------------------------
  Question                            Gold ID → 日志排名
  ----------------------------------- -----------------------------------
  q1                                  224 → 2；232 → 4；242 → 12；245 →
                                      8；246 → 10；281 → 5

  q2                                  45 → 6

  q3                                  31 → 4；32 → 1

  q4                                  162 → 1；163 → 3；164 → 10；167 → 4

  q5                                  157 → 10；158 → 2；159 → 22；224 →
                                      24；241 → 未出现；245 → 69；246 →
                                      27；280 → 54
  -----------------------------------------------------------------------

注意：`245 → 69` 超出配置中显示的 Top-60
范围。它可能来自更深的诊断排名，或显示日志与配置口径不一致；在重新检查原始脚本/日志前，不对此作推断。

两次运行还记录过：q2 的 Gold ID 45 在关闭时 rank 6、开启时 rank 7；q4
的候选池大小分别出现 112 和 113；q5 的候选池大小分别出现 89 和
100。当前归档上下文无法明确对应每个数值的开关状态，因此不擅自分配。

**证据等级：中等。** 指标与部分诊断来自控制台日志；当次 Production
源码快照未在本轮完整核对。

## 5. 历史检索与 Chunking 评估

这些结果用于历史基准，不与当前 HyDE 或 Production Top-K 直接合并。

### 5.1 早期固定长度分块基准（330 chunks）

参数：`chunk_size=500`、`chunk_overlap=100`。指标顺序：P@5 / Recall@5 /
MAP@5 / MRR@5。

  方法                     P@5   Recall@5    MAP@5    MRR@5
  ------------------- -------- ---------- -------- --------
  Dense                 0.1200     0.3000   0.0900   0.1000
  BM25                  0.1600     0.5000   0.2650   0.3500
  Hybrid                0.2000     0.6000   0.2733   0.4167
  Hybrid + Reranker     0.2800     0.7400   0.3230   0.4233

### 5.2 Fixed / Recursive / Semantic 分块对照

历史记录中的 chunk 数量：Fixed 340、Recursive 340、Semantic
385。指标顺序：P@5 / Recall@5 / MAP@5 / MRR@5。

  分块策略    方法                     P@5   Recall@5    MAP@5    MRR@5
  ----------- ------------------- -------- ---------- -------- --------
  Fixed       BGE Reranker          0.3600     0.7167   0.3981   0.6500
  Recursive   Dense                 0.2000     0.3500   0.1833   0.5067
  Recursive   BM25                  0.2800     0.4667   0.4517   0.6000
  Recursive   Hybrid                0.3200     0.6333   0.4089   0.7000
  Recursive   Hybrid + Reranker     0.3200     0.6167   0.3331   0.6000
  Semantic    Dense                 0.2400     0.3733   0.1844   0.4333
  Semantic    BM25                  0.2800     0.4500   0.4106   0.6000
  Semantic    Hybrid                0.2800     0.5667   0.4367   0.7000
  Semantic    Hybrid + Reranker     0.3600     0.6633   0.3510   0.6667

Fixed / Recursive / Semantic 的历史 chunk 数量与项目后来重建的
330、326、364 chunks 版本不同；复现时必须确认使用哪版索引。

### 5.3 另一轮早期五题整体基准

指标顺序：P@5 / Recall@5 / MAP@5 / MRR@5。

  方法                     P@5   Recall@5    MAP@5    MRR@5
  ------------------- -------- ---------- -------- --------
  Dense                 0.1600     0.3667   0.1533   0.2400
  BM25                  0.1200     0.2667   0.1417   0.3500
  Hybrid                0.2000     0.4667   0.3000   0.4667
  Hybrid + Reranker     0.2800     0.5733   0.2497   0.4567

另有更早一轮 Semantic 结果： -
Dense：`P@5=0.2000, Recall@5=0.3733, MAP@5=0.1389, MRR@5=0.2733` -
BM25：`P@5=0.1600, Recall@5=0.4000, MAP@5=0.2822, MRR@5=0.3667`

以上均为历史记录；复现前应核对当时的问题集、Gold
Evidence、索引和脚本版本。

## 6. Gold Evidence Coverage 诊断

此前一次证据覆盖检查记录：

-   Gold IDs：`[160, 161, 162, 246, 251]`
-   Found：`[160, 161, 251]`
-   Missing：`[162, 246]`
-   Coverage：`3/5 = 0.6000`

这是特定一轮的 Gold Evidence Coverage 诊断，不应与后续 HyDE/Production
运行的 Gold IDs
混为一谈。它提示当时仍有证据未被找到，需要区分原因是检索、chunk
划分、Gold quote 到 chunk 的映射，还是问题集/索引版本不一致。

## 7. 指标定义

-   **Precision@K：** 前 K 条结果中相关结果所占比例。
-   **Recall@K：** 前 K 条找到的 Gold Evidence 数量除以全部 Gold
    Evidence 数量。
-   **AP@K：** Average
    Precision@K，考虑相关结果在排序列表中的位置；相关结果越靠前通常越有利。
-   **MAP@K：** 所有有效问题的 AP@K 平均值。
-   **RR@K：** 第一个相关结果排名为 r 时取 `1/r`；前 K
    条没有相关结果时为 0。
-   **MRR@K：** 所有有效问题的 RR@K 平均值。

Gold Evidence 数量发生变化时，即使检索列表相同，Recall 也可能变化。Gold
Evidence 映射规则和有效问题数必须随指标一起记录。

## 8. 版本差异与比较规则

1.  不把 `main.py` 的定性输出当作整体指标。
2.  不把 `run_evaluation.py`、HyDE、Production Top-K
    放进同一张排行榜；它们的查询流程、候选池和问题集版本并不完全一致。
3.  HyDE 实验的 RRF 是 Dense + HyDE Dense，不是 Dense + BM25。
4.  不把 `USE_MULTI_QUERY` 自动视为 `main.py` Rewrite
    开关；要以每份脚本源码为准。
5.  Gold Evidence 曾变化：历史 `run_evaluation.py` q5 使用
    `[157, 158, 159, 241, 246]`；最新 HyDE q5 使用
    `[157, 158, 159, 224, 241, 245, 246, 280]`。
6.  问题集版本曾变化：本档案中的历史日志 q3 是 scaled dot-product
    attention、q4 是 data augmentation；项目后来记录过 q3 Multi-Head
    Attention、q4 Local Response Normalization。运行前需核对当前
    `evaluation/questions.json`。
7.  Chunk ID 只在对应 chunks 文件版本内有意义；重建 chunking 后，旧 ID
    不一定对应新索引中的同一文本。
8.  `RRF_TOP_K=60` 是候选融合截断；Top-5/10/20 是最终评估截断。Union
    候选数会因多路结果合并与去重而变化。
9.  指标差异不一定只来自算法，也可能来自 Gold
    Evidence、问题集、Prompt、候选池、索引或实现版本变化。

## 9. 下一步建议：先审计 HyDE 与 Production 的接入方式

当前最合理的下一步不是马上增加新的 Query Optimization 技术，而是先做一次
**HyDE 与 Production 流程的接入审计**，确认：

1.  `run_hyde_evaluation.py` 是独立实验脚本，还是已经接入 `main.py`
    的实际检索链路？
2.  生产流程是否保留真正的 Dense + BM25 + RRF？HyDE Dense
    结果应怎样加入候选池，再由 Cross-Encoder 统一重排序？
3.  所有比较是否使用同一份 `evaluation/questions.json`、相同的 Gold
    Evidence 映射规则，以及同一套 Semantic index/chunks？

确认后再设计单变量对照：**Production Baseline vs. Production + HyDE
candidates**。固定问题集、Gold Evidence、候选规模和
reranker，只改变是否加入 HyDE 候选，并统一报告 Top-5/10/20。这样才能判断
HyDE 是否真正改善生产检索，而不是只改善独立 Dense 检索实验。

### 推荐的下一个单独操作

先打开并核对 `evaluation/run_hyde_evaluation.py` 与
`run_production_topk_evaluation.py`
的关键检索函数和候选融合部分，暂时不改代码。核对完成后，再决定最小的集成改动。

## 10. 完整性说明

本文件汇总截至 2026-10-17
可访问的项目记忆、已读取源码和控制台输出中能够恢复的结果。它尽可能保存已知的整体指标和近期关键逐题数据，但不代表每一轮历史运行的原始控制台文件都已找回。未能确认的源码版本、配置对应关系和旧版
Gold Evidence 均已标注，没有用推测补齐。

## 11. 2026-10-18：来源信息与上下文选择三组受控回归

已实际运行 `python -m evaluation.run_context_selection_evaluation`，完成 q1–q5。HyDE OFF，Rewrite OFF，Dense/BM25 Top-60，RRF Top-60、K=60，BGE reranker CPU，最终 Top-10；C 每个子查询最多预留 3 条。每题仅拆解、检索一次，各组共享候选池及子查询，Gold Evidence 与 claim mapping 未改动。

| 组别 | Precision@10 | Recall@10 | MAP@10 | MRR@10 | q5 必需论点覆盖 |
|---|---:|---:|---:|---:|---:|
| A：正文 / 全局 Top-10 | 0.2800 | 0.8167 | 0.4283 | 0.6333 | 2/4 |
| B：来源＋正文 / 全局 Top-10 | 0.3200 | 0.8667 | 0.5784 | 0.7667 | 4/4 |
| C：来源＋正文 / 子查询选择器 | 0.3200 | 0.8667 | 0.5784 | 0.7667 | 4/4 |

**结论与限制：** B/C 在五题上的 Top-10 IDs 全部一致，未证明选择器相对 B 有额外收益。来源信息提高当前五题整体指标，但 q3 AP 从 0.7500 降至 0.5000、RR 从 1.0000 降至 0.5000；q4 AP 从 0.7042 降至 0.6917；q5 RR 从 0.5000 降至 0.3333，同时必需论点覆盖改善。q6 无 Gold，跳过排名指标；本轮未评价答案正确性、引用语义支持或拒答。

**可复现记录：** `context_selection_inputs.json` 保存冻结候选 ID 和子查询；`context_selection_results.json` 保存逐题指标、选中 ID、数据及代码哈希；`context_selection_results.md` 提供可读报告。默认复用冻结输入，显式传 `--refresh-inputs` 才重新生成。当前 main.py 仍调用 C，未根据本轮结果自动切换策略。

## 12. 2026-10-18：固定 q5 上下文的事实表诊断

后续核对用户编辑后的 main.py，当前已调用 B（来源＋正文的全局排序）；C 函数保留用于实验。以下实验未修改生产流程。

新增 `diagnose_q5_evidence.py`，直接复用 `q5_answer_baseline.json` 的十个片段和顺序，逐片段提取通用事实字段，再用记录生成一次答案。不重新检索、不补前文、不向模型提供 Gold。程序仅检查 JSON、真实引文子串、未知主体及引用编号，不验证语义支持。

共保存三轮探索结果。前两轮六字段接口没有 eligible 记录，未生成答案；第三轮简化为 subject/claim/quote，十个片段产生八条记录、两个空列表，全部八条记录通过结构/引文检查。11 次本地 Qwen 调用耗时 71.32 秒（含首次模型加载，不含进程启动导入），结果为 `q5_evidence_diagnostic_v3.json`。相较基线，DCNN 第二层 5×5、第三至第五层 3×3 进入答案，最终数量/尺寸混淆未再出现。

**答案验收仍未通过：** VGG 的 5×5 误归属持续存在，3×3 被过度概括为所有层；中间记录还有把通道宽度写成滤波器尺寸的错误。四项核心信息出现不等于四项严格验收全部通过，引用编号有效不等于引用支持事实。六项确定性流程检查通过，不能代表模型语义正确。

完整人工审计、失败轮次、限制和复现命令见 `q5_evidence_review.md`。这是在 q5 上迭代的组合方案探索，未做独立因素消融或未见问题泛化验证；不据此集成生产或声称整体准确率提升。

## 13. 2026-10-18：只补充 HWC/数量/通道定义的对照

在通用三字段提取提示词中加入 `NUMERIC_SEMANTICS_RULES`，只提供 H×W×C、核数量和通道数的定义，不含题目标准答案。十个提取提示词删去该段后逐字等于第三轮提示词；模型、问题、十个片段及顺序、上下文、生成设置和汇总构建逻辑不变。15 项输入/运行完整性检查与原有六项流程检查通过。

实际执行 `diagnose_q5_evidence.py --output evaluation/results/q5_evidence_numeric_rules.json`：11 次调用、60.76 秒、九条结构合格记录。最终已有规格表达为二维空间尺寸，但通道宽度的语义错误和 VGG 的主体误归属未解决；第三、第五层从事实表和最终答案中丢失。答案还使用 [N.1] 事实 ID 作引用，并错误声称没有 DCNN 首层证据，与自身答案和记录 9.1 矛盾。VGG 的 all layers 过度概括仍存在。

**判定：本轮未取得预期的整体改善，答案验收失败。** `status=complete` 仅表示运行完成；`invalid=[]` 不能掩盖 `has_citations=False`。九条记录相较八条不是准确率提升，单次耗时变化也不是速度基准。11 次生成均未触及 512 token 上限。本轮未继续挑选更好提示词输出或改动生产流程。

完整人工报告、控制条件与原始产物见 `q5_numeric_rules_review.md`、`q5_numeric_rules_comparison.json`、`q5_evidence_numeric_rules.json`。建议下一步做显式规格的数值解析与逐层完整性检查、程序引用渲染和独立主体校验；这些修复尚未实现。泛化验证仍待完成。

## 14. 2026-10-18：确定性数值解析与简短上下文

新增 `src/numeric_evidence.py`：从明确英文卷积规格提取层号、核数量、二维空间尺寸和每核通道深度；保留精确原文和字符位置，未知语法不猜。真实五层逐字段正确，图像尺寸/通道宽度等反例通过；加上流程与引用检查共 21 项测试通过。

独立诊断 `diagnose_q5_numeric_pipeline.py` 使用同一冻结 q5 原始十段，无检索、无补前文、无 Gold 输入。首先执行数值表＋相关原始片段、数值表＋作者自述筛选两个 JSON 呈现分支，均未通过答案验收，完整保留在 `q5_numeric_pipeline.json`。随后一次 compact 分支以简短数值句和优先架构段落组织上下文，复用当前 main.build_prompt：正确比较 VGG 3×3 与 DCNN 11×11/5×5/3×3，无 VGG 5×5 误归属，引用 [3]、[6]、[9]、[10] 有效。本次分支一个模型调用、28.87 秒；各分支计时不作为性能基准。

**结果边界：** 程序表格完整保留五层；模型摘要未完整写出所有层号对应关系，也遗漏 VGG 1×1 配置。结构化解析通过当前测试，模型摘要改善，但不记作严格完整答案全部通过。改善来自解析、保守作者筛选和上下文重组的组合；架构元数据与作者自述是有限归属假设，并非通用实体识别。没有生产接入或跨问题泛化结论。按用户要求在取得改善后停止调参。

完整报告 `NUMERIC_EVIDENCE_REPORT.md` 含程序数值表、VGG 原文证据、模型未经改写的摘要、失败过程、限制与复现命令；最终原始记录为 `q5_numeric_pipeline_compact.json`，验收记录为 `numeric_pipeline_acceptance.json`。

## 15. 2026-10-18：前四项问题的受限 grounding 与本地泛化挑战

新增 `src/grounded_evidence.py`，实现明确主体/有限前文锚点、类型化支撑校验、逐字引用退路和完整证据视图；扩展数值解析至 filters 句式、标签字段和明确 Markdown 表头。27项开发/回归检查通过。未修改 main.py、llm.py、问题集、Gold 或原始 q5 基线。

预先固定43个本地数值案例（45条预期规格）和16个主体案例，代码冻结后运行评估，不针对失败调参。旧解析器完整匹配10/45，新解析器42/45；完整元组精确率90.91%→97.67%，召回22.22%→93.33%。中文、by语法和跨句层号仍失败；六个无规格反例无误提。此集为作者设计的模板化挑战，并非外部独立盲测。

16个主体案例全部命中，但真实 chunk 250 出现会议缩写 ICLR 被当成主体候选，主体泛化仍未解决；原始错误完整保留。当前直接引文视图不把这个候选标签输出为世界事实，后续消费者也不能将 subject 字段当作已验证实体。

q1–q5真实证据回归生成126条规范记录（其中5条数值、121条引文），支撑检查全部接纳，524个本地构造篡改全部拒绝。任意自由改写不在协议内，包括五条真实但自由表达的数值改写也被拒绝，不能把这些结果解释为通用语义蕴含准确率。实际Qwen选择q5的8/25条、q2的3/24条，程序分别恢复17/21条。完整性只指已接纳记录，不是答案/检索召回。

完整报告 `GROUNDING_GENERALIZATION_REPORT.md`，原始无模型/模型评估 `grounding_generalization.json`、`grounding_generalization_model.json`，边界审计 `grounding_scope_audit.json`，证据视图 `grounding_q5_evidence.md`、`grounding_q2_evidence.md`。记录了代码冻结、所有失败和范围限制。没有宣称前四项问题全部解决，也没有生产接入。

## 16. 2026-10-18：独立可读演示与原型阶段收尾

新增 `demo_grounded_qa.py`，仅复用冻结 q5/q2 检索结果，输出模型短答草稿、程序关键事实、引用和完整附件。修复真实出现的 `we also utilise` 归属识别缺口；首轮 q5 补充证据重复占用同一片段，调整为每片段最多一条后仅重跑 q5，首轮记录保留。共三次模型调用，未新增测试集或重跑大评估。

q5 关键视图完整保留五层数值及 VGG 1×1/3×3 证据；q2 回答位置编码的核心动机。摘要引用编号均有效，但 q5 提及5×5未直接引用[3]，逐层映射靠正确程序表格保留；q2还包含次要实现细节。不宣称严格语义验收全部通过。核对了所选记录、附件引用、完整台账及 main/model/Gold 哈希未变。

报告 `STAGE_CLOSEOUT_REPORT.md`：可收尾“上下文与证据管理的独立原型/演示”阶段，仍不集成主流程。演示 `grounded_demo/q5.md`、`q2.md`，原始提示词、回答和台账在相邻 JSON；完整证据另存附件。未提供任意输入的新检索服务，也没有由两例推导泛化或整体准确率。


## 17. 2026-10-18：用户授权证据管理接入 main

在全局重排序后接入证据台账与数值/主体解释，保留全部 Top-10 原文，并把身份前文锚点追加到统一引用表。终端先输出程序事实、原文及来源，再输出模型草稿。没有迁入固定题目筛选规则，没有改变检索与模型配置。

17 项现有组件检查通过；q5/q2 各执行一次真实 main 全链路，包含实际分解、检索、重排序和生成。Top-10 与历史 B 相同，q5/q2 含锚点的原文为12/10条，台账25/24条；q5五层数值正确。引用编号均无越界，但这不代表语义支撑全部正确。

首轮 q5 仍将 GoogLeNet 的5×5归给VGG；把解释提示移至原文之后，仅重跑同一实时检索结果的 q5 生成，最终该误归属消失。q2 输入保持一致，未重跑。本轮共五次模型调用。最终 q5 仍遗漏 VGG 1×1、过度概括所有层并存在不直接支持结论的引用；q2 核心解释正确，引用位置欠佳。严格答案验收仍未通过，没有执行接入前后的完整答案对照，也不宣称泛化提升。

报告 `MAIN_EVIDENCE_INTEGRATION_REPORT.md`；可读结果及原始上下文/答案/首轮失败/检查记录位于 `main_evidence_integration/`。模型、数据、Gold 哈希未变，main 修改已获用户授权。


## 18. 2026-10-18：main 引用结构检查与一次受限修复

将评估侧引用检查迁入 src/citation_validation.py，保留兼容导入。main 初答后检查缺失/越界/可识别畸形引用，对失败最多生成一次“段落→来源编号”映射，由程序插入编号并保留原句；有效引用及明确证据不足措辞跳过。无效或不完整映射保留初答，不继续重试。

完整 q1 main 首轮复现原始无引用答案与相同上下文；模型误把七段答案映射为十一项，程序拒绝。将段落 ID 与来源编号分为 B1–B7/数字后，只重跑修复一步，得到七项合法映射，原句保留。共四次实际模型调用；末尾换行的引用位置仅重渲染，零新增调用。三项小型回归检查通过，另对保存的 q2–q6 答案回放后处理，均不增加模型调用或改变答案。

结构修复成功不等于语义通过：q1 B1 的16–19层性能结论和 B3 的参数比较仍引用不完整，原有解释遗漏与过度概括未被改写；q3/q4 的因果混淆也不会被格式检查发现。严格 q1 答案验收仍失败。报告 CITATION_REPAIR_REPORT.md，原始/修复/首轮失败和回放记录在 citation_repair/。模型、数据、Gold 与检索配置未改，无泛化成绩声明。


## 19. 2026-10-18：Kimi3 全生成链路迁移与回归

用户选择反代 cn:kimi-k3-1 并弃用本地生成模型。llm.py 改为 API 公共入口，main/问题分解/引用修复及可选改写/HyDE 的生成路径统一；原 Qwen 实现按旧哈希保存为 evaluation/baselines/local_qwen_llm.py，无本地回退，未删除权重。保留本地 CPU 检索模型。按 K3 文档配置 low reasoning_effort、4096 max_completion_tokens，移除不兼容的温度/关闭思考参数。

34项相关组件检查通过，六题真实 main 全链路均完成，共12次成功API调用、无引用修复触发。五个数值/实体窄案例全部通过；q4另用旧完整提示词和证据做一次对照，也通过人工审阅。q1/q2/q3/q5 与2B提示词、Top-10完全相同，q4/q6因分解改变而不同。主要旧错误在本次输出中消失，但q5仍有上下文未明示的AlexNet别名与绝对化措辞，严格source-only不算全通过；q6仍仅单例拒答验证。

两次503分别发生在q1、q4分解，失败日志保留；独立最小OK探测成功，随后只继续未完成问题。共21次请求，19成功/2失败；不推断一般故障率或无故障承诺。模型/服务参数和预算也变化，不把质量改善只归因于参数量，不声称一般准确率或速度提升。数据、索引、问题和Gold哈希不变，Key未进入结果。

报告 KIMI_MIGRATION_REPORT.md，结果 kimi_main_evaluation/；PyCharm接入教程 docs/PYCHARM_API_GUIDE.md 与 api.example.json。阶段6首轮现有案例审阅可有限收尾，下一步有界Single-Agent原型，尚未实现Agent/LangGraph。
